﻿Public Interface CCToonUctrl
    Sub UpdateCartoons()
    Property ShowFeedBackLabels() As Boolean
    Property SharedValveStates() As Integer
    Property GroupValveStates() As Integer
    Property PaintColorName() As String
    Property SolvHeaderLabel() As String
    Property AirHeaderLabel() As String
    Sub SetSharedValveLabels(ByRef sNames As String())
    Sub SetGroupValveLabels(ByRef sNames As String())
    Sub SetAdditionalData(ByRef sData As String())
    Event GroupValveClick(ByVal nValve As Integer, ByVal nCurState As Boolean)
    Event SharedValveClick(ByVal nValve As Integer, ByVal nCurState As Boolean)
End Interface
