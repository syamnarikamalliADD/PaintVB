﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uctrlVersabell2_2k
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uctrlVersabell2_2k))
        Me.lblAirHeaderLine1 = New System.Windows.Forms.Label
        Me.lblSolventHeader1 = New System.Windows.Forms.Label
        Me.lblPntHeader01 = New System.Windows.Forms.Label
        Me.lblAirHeader01 = New System.Windows.Forms.Label
        Me.lblSolventHeader2 = New System.Windows.Forms.Label
        Me.lblColorHeader2 = New System.Windows.Forms.Label
        Me.lblAirHeaderLine2 = New System.Windows.Forms.Label
        Me.lblLineBW2 = New System.Windows.Forms.Label
        Me.lblLineDump2_2 = New System.Windows.Forms.Label
        Me.lblLineDump2_1 = New System.Windows.Forms.Label
        Me.lblAirHeaderLine3 = New System.Windows.Forms.Label
        Me.lblLineColStk3 = New System.Windows.Forms.Label
        Me.lblLineSolvAir = New System.Windows.Forms.Label
        Me.lblLineColStk2 = New System.Windows.Forms.Label
        Me.lblSolventHeader3 = New System.Windows.Forms.Label
        Me.lblGroup14 = New System.Windows.Forms.Label
        Me.lblLineDump1 = New System.Windows.Forms.Label
        Me.lblGroup00 = New System.Windows.Forms.Label
        Me.lblDumpTank = New System.Windows.Forms.Label
        Me.lblGroup04 = New System.Windows.Forms.Label
        Me.lblGroup03 = New System.Windows.Forms.Label
        Me.lblGroup06 = New System.Windows.Forms.Label
        Me.lblGroup05 = New System.Windows.Forms.Label
        Me.lblGroup01 = New System.Windows.Forms.Label
        Me.lblGroup02 = New System.Windows.Forms.Label
        Me.lblShared03 = New System.Windows.Forms.Label
        Me.lblShared00 = New System.Windows.Forms.Label
        Me.lblLineColStk1 = New System.Windows.Forms.Label
        Me.lblLineBellMan2 = New System.Windows.Forms.Label
        Me.lblGroup09 = New System.Windows.Forms.Label
        Me.lblLineSealAir = New System.Windows.Forms.Label
        Me.lblGroup08 = New System.Windows.Forms.Label
        Me.picDumpTank = New System.Windows.Forms.PictureBox
        Me.lblOutPressure = New System.Windows.Forms.Label
        Me.lblOutPressureTag = New System.Windows.Forms.Label
        Me.picApplCleaner = New System.Windows.Forms.PictureBox
        Me.lblLineACA = New System.Windows.Forms.Label
        Me.lblLineACS = New System.Windows.Forms.Label
        Me.lblOutPressure2 = New System.Windows.Forms.Label
        Me.lblShared01 = New System.Windows.Forms.Label
        Me.lblShared02 = New System.Windows.Forms.Label
        Me.lblGroup12 = New System.Windows.Forms.Label
        Me.lblGroup11 = New System.Windows.Forms.Label
        Me.lblGroup10 = New System.Windows.Forms.Label
        Me.lblGroup07 = New System.Windows.Forms.Label
        Me.lblGroup15 = New System.Windows.Forms.Label
        Me.lblGroup13 = New System.Windows.Forms.Label
        Me.lblAirHeaderLine4 = New System.Windows.Forms.Label
        Me.lblSolventHeader4 = New System.Windows.Forms.Label
        Me.lblLineWashOut1 = New System.Windows.Forms.Label
        Me.lblLineSolvAir1 = New System.Windows.Forms.Label
        Me.lblLineSolvAir2 = New System.Windows.Forms.Label
        Me.lblLineColStk5 = New System.Windows.Forms.Label
        Me.lblLineBellMan1 = New System.Windows.Forms.Label
        Me.lblLinMix02 = New System.Windows.Forms.Label
        Me.picVersabellGearsPump01 = New System.Windows.Forms.PictureBox
        Me.lblFlow = New System.Windows.Forms.Label
        Me.lblFlowTag = New System.Windows.Forms.Label
        Me.lblGroup26 = New System.Windows.Forms.Label
        Me.lblGroup25 = New System.Windows.Forms.Label
        Me.lblGroup23 = New System.Windows.Forms.Label
        Me.lblGroup22 = New System.Windows.Forms.Label
        Me.lblGroup21 = New System.Windows.Forms.Label
        Me.lblGroup20 = New System.Windows.Forms.Label
        Me.lblGroup19 = New System.Windows.Forms.Label
        Me.lblGroup18 = New System.Windows.Forms.Label
        Me.lblGroup17 = New System.Windows.Forms.Label
        Me.lblGroup16 = New System.Windows.Forms.Label
        Me.lblGroup31 = New System.Windows.Forms.Label
        Me.lblGroup30 = New System.Windows.Forms.Label
        Me.lblGroup29 = New System.Windows.Forms.Label
        Me.lblGroup28 = New System.Windows.Forms.Label
        Me.lblGroup27 = New System.Windows.Forms.Label
        Me.lblGroup24 = New System.Windows.Forms.Label
        Me.lblLineSolvAirOut1 = New System.Windows.Forms.Label
        Me.lblLineACA2 = New System.Windows.Forms.Label
        Me.lblLineACA3 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblLineACVA = New System.Windows.Forms.Label
        Me.picVersabellGearsPump02 = New System.Windows.Forms.PictureBox
        Me.Label2 = New System.Windows.Forms.Label
        Me.lblSolventHeader5 = New System.Windows.Forms.Label
        Me.lblLineWashOut2 = New System.Windows.Forms.Label
        Me.lblSolventHeader6 = New System.Windows.Forms.Label
        Me.linHdrStack01 = New System.Windows.Forms.Label
        Me.linHdrStack02 = New System.Windows.Forms.Label
        Me.lblLineSolvAirOut2 = New System.Windows.Forms.Label
        Me.lblLineDump3_1 = New System.Windows.Forms.Label
        Me.lblLineColStk4 = New System.Windows.Forms.Label
        Me.linHdrStack03 = New System.Windows.Forms.Label
        Me.lblLinMix01 = New System.Windows.Forms.Label
        Me.lblOutPressure2Tag = New System.Windows.Forms.Label
        Me.lblSolventHeader7 = New System.Windows.Forms.Label
        Me.lblLineFlush2_1 = New System.Windows.Forms.Label
        Me.lblLineFlush2_2 = New System.Windows.Forms.Label
        Me.lblLineFlush = New System.Windows.Forms.Label
        Me.UctrlGroupValve31 = New uctrlValve
        Me.UctrlGroupValve25 = New uctrlValve
        Me.UctrlGroupValve30 = New uctrlValve
        Me.UctrlGroupValve29 = New uctrlValve
        Me.UctrlGroupValve28 = New uctrlValve
        Me.UctrlGroupValve27 = New uctrlValve
        Me.UctrlGroupValve24 = New uctrlValve
        Me.UctrlGroupValve23 = New uctrlValve
        Me.UctrlGroupValve22 = New uctrlValve
        Me.UctrlGroupValve20 = New uctrlValve
        Me.UctrlGroupValve19 = New uctrlValve
        Me.UctrlGroupValve18 = New uctrlValve
        Me.UctrlGroupValve17 = New uctrlValve
        Me.UctrlGroupValve21 = New uctrlValve
        Me.UctrlGroupValve16 = New uctrlValve
        Me.UctrlGroupValve26 = New uctrlValve
        Me.UctrlGroupValve14 = New uctrlValve
        Me.UctrlSharedValve0 = New uctrlValve
        Me.UctrlSharedValve0b = New uctrlValve
        Me.UctrlGroupValve13 = New uctrlValve
        Me.UctrlGroupValve15 = New uctrlValve
        Me.UctrlGroupValve10 = New uctrlValve
        Me.UctrlGroupValve11 = New uctrlValve
        Me.UctrlGroupValve12 = New uctrlValve
        Me.UctrlGroupValve9 = New uctrlValve
        Me.UctrlGroupValve8 = New uctrlValve
        Me.UctrlGroupValve7 = New uctrlValve
        Me.UctrlGroupValve6 = New uctrlValve
        Me.UctrlGroupValve5 = New uctrlValve
        Me.UctrlGroupValve4 = New uctrlValve
        Me.UctrlGroupValve3 = New uctrlValve
        Me.UctrlGroupValve2 = New uctrlValve
        Me.UctrlGroupValve1 = New uctrlValve
        Me.UctrlSharedValve0a = New uctrlValve
        Me.UctrlGroupValve0 = New uctrlValve
        Me.UctrlSharedValve3 = New uctrlValve
        Me.UctrlSharedValve1 = New uctrlValve
        Me.UctrlSharedValve2 = New uctrlValve
        Me.lblLineDump3_2 = New System.Windows.Forms.Label
        Me.lblInPressureTag = New System.Windows.Forms.Label
        Me.lblInPressure2 = New System.Windows.Forms.Label
        Me.lblInPressure = New System.Windows.Forms.Label
        CType(Me.picDumpTank, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picApplCleaner, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picVersabellGearsPump01, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picVersabellGearsPump02, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblAirHeaderLine1
        '
        Me.lblAirHeaderLine1.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine1.Location = New System.Drawing.Point(12, 31)
        Me.lblAirHeaderLine1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine1.Name = "lblAirHeaderLine1"
        Me.lblAirHeaderLine1.Size = New System.Drawing.Size(3, 518)
        Me.lblAirHeaderLine1.TabIndex = 92
        '
        'lblSolventHeader1
        '
        Me.lblSolventHeader1.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.lblSolventHeader1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblSolventHeader1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader1.Location = New System.Drawing.Point(1, 41)
        Me.lblSolventHeader1.Name = "lblSolventHeader1"
        Me.lblSolventHeader1.Size = New System.Drawing.Size(314, 15)
        Me.lblSolventHeader1.TabIndex = 94
        Me.lblSolventHeader1.Text = "Purge Solvent"
        Me.lblSolventHeader1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblPntHeader01
        '
        Me.lblPntHeader01.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblPntHeader01.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lblPntHeader01.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblPntHeader01.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblPntHeader01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPntHeader01.Location = New System.Drawing.Point(1, 1)
        Me.lblPntHeader01.Name = "lblPntHeader01"
        Me.lblPntHeader01.Size = New System.Drawing.Size(314, 19)
        Me.lblPntHeader01.TabIndex = 95
        Me.lblPntHeader01.Text = "Paint"
        Me.lblPntHeader01.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAirHeader01
        '
        Me.lblAirHeader01.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeader01.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lblAirHeader01.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblAirHeader01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeader01.Location = New System.Drawing.Point(1, 23)
        Me.lblAirHeader01.Name = "lblAirHeader01"
        Me.lblAirHeader01.Size = New System.Drawing.Size(314, 14)
        Me.lblAirHeader01.TabIndex = 96
        Me.lblAirHeader01.Text = "Purge Air"
        Me.lblAirHeader01.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblSolventHeader2
        '
        Me.lblSolventHeader2.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader2.Location = New System.Drawing.Point(5, 47)
        Me.lblSolventHeader2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader2.Name = "lblSolventHeader2"
        Me.lblSolventHeader2.Size = New System.Drawing.Size(3, 462)
        Me.lblSolventHeader2.TabIndex = 93
        '
        'lblColorHeader2
        '
        Me.lblColorHeader2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblColorHeader2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblColorHeader2.Location = New System.Drawing.Point(172, 15)
        Me.lblColorHeader2.Name = "lblColorHeader2"
        Me.lblColorHeader2.Size = New System.Drawing.Size(3, 51)
        Me.lblColorHeader2.TabIndex = 121
        '
        'lblAirHeaderLine2
        '
        Me.lblAirHeaderLine2.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine2.ForeColor = System.Drawing.Color.Black
        Me.lblAirHeaderLine2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine2.Location = New System.Drawing.Point(14, 267)
        Me.lblAirHeaderLine2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine2.Name = "lblAirHeaderLine2"
        Me.lblAirHeaderLine2.Size = New System.Drawing.Size(18, 3)
        Me.lblAirHeaderLine2.TabIndex = 126
        Me.lblAirHeaderLine2.Text = "_linAirHeader_40"
        '
        'lblLineBW2
        '
        Me.lblLineBW2.BackColor = System.Drawing.Color.Black
        Me.lblLineBW2.ForeColor = System.Drawing.Color.Black
        Me.lblLineBW2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineBW2.Location = New System.Drawing.Point(99, 425)
        Me.lblLineBW2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineBW2.Name = "lblLineBW2"
        Me.lblLineBW2.Size = New System.Drawing.Size(19, 3)
        Me.lblLineBW2.TabIndex = 122
        '
        'lblLineDump2_2
        '
        Me.lblLineDump2_2.BackColor = System.Drawing.Color.Black
        Me.lblLineDump2_2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineDump2_2.Location = New System.Drawing.Point(294, 195)
        Me.lblLineDump2_2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineDump2_2.Name = "lblLineDump2_2"
        Me.lblLineDump2_2.Size = New System.Drawing.Size(3, 247)
        Me.lblLineDump2_2.TabIndex = 112
        '
        'lblLineDump2_1
        '
        Me.lblLineDump2_1.BackColor = System.Drawing.Color.Black
        Me.lblLineDump2_1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineDump2_1.Location = New System.Drawing.Point(206, 194)
        Me.lblLineDump2_1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineDump2_1.Name = "lblLineDump2_1"
        Me.lblLineDump2_1.Size = New System.Drawing.Size(91, 3)
        Me.lblLineDump2_1.TabIndex = 113
        '
        'lblAirHeaderLine3
        '
        Me.lblAirHeaderLine3.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine3.Location = New System.Drawing.Point(14, 88)
        Me.lblAirHeaderLine3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine3.Name = "lblAirHeaderLine3"
        Me.lblAirHeaderLine3.Size = New System.Drawing.Size(57, 3)
        Me.lblAirHeaderLine3.TabIndex = 114
        '
        'lblLineColStk3
        '
        Me.lblLineColStk3.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk3.Location = New System.Drawing.Point(161, 146)
        Me.lblLineColStk3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk3.Name = "lblLineColStk3"
        Me.lblLineColStk3.Size = New System.Drawing.Size(3, 156)
        Me.lblLineColStk3.TabIndex = 115
        '
        'lblLineSolvAir
        '
        Me.lblLineSolvAir.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAir.ForeColor = System.Drawing.Color.Black
        Me.lblLineSolvAir.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAir.Location = New System.Drawing.Point(99, 88)
        Me.lblLineSolvAir.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAir.Name = "lblLineSolvAir"
        Me.lblLineSolvAir.Size = New System.Drawing.Size(3, 90)
        Me.lblLineSolvAir.TabIndex = 116
        '
        'lblLineColStk2
        '
        Me.lblLineColStk2.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk2.Location = New System.Drawing.Point(130, 146)
        Me.lblLineColStk2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk2.Name = "lblLineColStk2"
        Me.lblLineColStk2.Size = New System.Drawing.Size(44, 3)
        Me.lblLineColStk2.TabIndex = 118
        '
        'lblSolventHeader3
        '
        Me.lblSolventHeader3.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader3.Location = New System.Drawing.Point(5, 145)
        Me.lblSolventHeader3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader3.Name = "lblSolventHeader3"
        Me.lblSolventHeader3.Size = New System.Drawing.Size(65, 3)
        Me.lblSolventHeader3.TabIndex = 120
        '
        'lblGroup14
        '
        Me.lblGroup14.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup14.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup14.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup14.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup14.Location = New System.Drawing.Point(38, 348)
        Me.lblGroup14.Name = "lblGroup14"
        Me.lblGroup14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup14.Size = New System.Drawing.Size(60, 29)
        Me.lblGroup14.TabIndex = 111
        Me.lblGroup14.Text = "Wash 14"
        Me.lblGroup14.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblLineDump1
        '
        Me.lblLineDump1.BackColor = System.Drawing.Color.Black
        Me.lblLineDump1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineDump1.Location = New System.Drawing.Point(278, 331)
        Me.lblLineDump1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineDump1.Name = "lblLineDump1"
        Me.lblLineDump1.Size = New System.Drawing.Size(3, 113)
        Me.lblLineDump1.TabIndex = 123
        '
        'lblGroup00
        '
        Me.lblGroup00.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup00.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup00.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup00.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup00.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup00.Location = New System.Drawing.Point(216, 354)
        Me.lblGroup00.Name = "lblGroup00"
        Me.lblGroup00.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup00.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup00.TabIndex = 110
        Me.lblGroup00.Text = "Paint Enbl 0"
        Me.lblGroup00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDumpTank
        '
        Me.lblDumpTank.BackColor = System.Drawing.Color.Transparent
        Me.lblDumpTank.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDumpTank.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblDumpTank.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDumpTank.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDumpTank.Location = New System.Drawing.Point(202, 438)
        Me.lblDumpTank.Name = "lblDumpTank"
        Me.lblDumpTank.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDumpTank.Size = New System.Drawing.Size(57, 29)
        Me.lblDumpTank.TabIndex = 109
        Me.lblDumpTank.Text = "Waste Recovery"
        Me.lblDumpTank.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup04
        '
        Me.lblGroup04.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup04.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup04.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup04.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblGroup04.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup04.Location = New System.Drawing.Point(29, 59)
        Me.lblGroup04.Name = "lblGroup04"
        Me.lblGroup04.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup04.Size = New System.Drawing.Size(40, 29)
        Me.lblGroup04.TabIndex = 108
        Me.lblGroup04.Text = "Purge Air 4"
        Me.lblGroup04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup03
        '
        Me.lblGroup03.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup03.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup03.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup03.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblGroup03.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup03.Location = New System.Drawing.Point(17, 111)
        Me.lblGroup03.Name = "lblGroup03"
        Me.lblGroup03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup03.Size = New System.Drawing.Size(53, 31)
        Me.lblGroup03.TabIndex = 107
        Me.lblGroup03.Text = "Purge Solvent 3"
        Me.lblGroup03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup06
        '
        Me.lblGroup06.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup06.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup06.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup06.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroup06.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup06.Location = New System.Drawing.Point(199, 305)
        Me.lblGroup06.Name = "lblGroup06"
        Me.lblGroup06.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup06.Size = New System.Drawing.Size(56, 26)
        Me.lblGroup06.TabIndex = 106
        Me.lblGroup06.Text = "Dump 6"
        Me.lblGroup06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup05
        '
        Me.lblGroup05.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup05.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup05.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup05.ForeColor = System.Drawing.Color.Black
        Me.lblGroup05.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup05.Location = New System.Drawing.Point(137, 97)
        Me.lblGroup05.Name = "lblGroup05"
        Me.lblGroup05.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup05.Size = New System.Drawing.Size(35, 40)
        Me.lblGroup05.TabIndex = 105
        Me.lblGroup05.Text = "pCC 05"
        Me.lblGroup05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup01
        '
        Me.lblGroup01.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup01.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup01.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup01.Location = New System.Drawing.Point(118, 318)
        Me.lblGroup01.Name = "lblGroup01"
        Me.lblGroup01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup01.Size = New System.Drawing.Size(49, 30)
        Me.lblGroup01.TabIndex = 104
        Me.lblGroup01.Text = "Injector Wash 1"
        Me.lblGroup01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup02
        '
        Me.lblGroup02.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup02.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup02.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup02.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup02.Location = New System.Drawing.Point(31, 393)
        Me.lblGroup02.Name = "lblGroup02"
        Me.lblGroup02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup02.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup02.TabIndex = 103
        Me.lblGroup02.Text = "Bell Wash 2"
        Me.lblGroup02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblShared03
        '
        Me.lblShared03.BackColor = System.Drawing.Color.Transparent
        Me.lblShared03.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared03.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared03.ForeColor = System.Drawing.Color.Black
        Me.lblShared03.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared03.Location = New System.Drawing.Point(181, 60)
        Me.lblShared03.Name = "lblShared03"
        Me.lblShared03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared03.Size = New System.Drawing.Size(39, 28)
        Me.lblShared03.TabIndex = 102
        Me.lblShared03.Text = "Color Enable 3"
        Me.lblShared03.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblShared00
        '
        Me.lblShared00.BackColor = System.Drawing.Color.Transparent
        Me.lblShared00.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared00.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared00.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared00.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared00.Location = New System.Drawing.Point(181, 413)
        Me.lblShared00.Name = "lblShared00"
        Me.lblShared00.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared00.Size = New System.Drawing.Size(68, 17)
        Me.lblShared00.TabIndex = 101
        Me.lblShared00.Tag = "0"
        Me.lblShared00.Text = "Trigger 0"
        Me.lblShared00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLineColStk1
        '
        Me.lblLineColStk1.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk1.Location = New System.Drawing.Point(172, 87)
        Me.lblLineColStk1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk1.Name = "lblLineColStk1"
        Me.lblLineColStk1.Size = New System.Drawing.Size(3, 60)
        Me.lblLineColStk1.TabIndex = 124
        '
        'lblLineBellMan2
        '
        Me.lblLineBellMan2.BackColor = System.Drawing.Color.Black
        Me.lblLineBellMan2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineBellMan2.Location = New System.Drawing.Point(155, 374)
        Me.lblLineBellMan2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineBellMan2.Name = "lblLineBellMan2"
        Me.lblLineBellMan2.Size = New System.Drawing.Size(3, 19)
        Me.lblLineBellMan2.TabIndex = 125
        '
        'lblGroup09
        '
        Me.lblGroup09.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup09.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup09.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup09.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroup09.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup09.Location = New System.Drawing.Point(172, 145)
        Me.lblGroup09.Name = "lblGroup09"
        Me.lblGroup09.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup09.Size = New System.Drawing.Size(65, 23)
        Me.lblGroup09.TabIndex = 100
        Me.lblGroup09.Text = "Dump-2 9"
        Me.lblGroup09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLineSealAir
        '
        Me.lblLineSealAir.BackColor = System.Drawing.Color.Black
        Me.lblLineSealAir.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSealAir.Location = New System.Drawing.Point(52, 266)
        Me.lblLineSealAir.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSealAir.Name = "lblLineSealAir"
        Me.lblLineSealAir.Size = New System.Drawing.Size(3, 18)
        Me.lblLineSealAir.TabIndex = 127
        '
        'lblGroup08
        '
        Me.lblGroup08.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup08.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup08.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup08.ForeColor = System.Drawing.Color.Black
        Me.lblGroup08.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup08.Location = New System.Drawing.Point(55, 245)
        Me.lblGroup08.Name = "lblGroup08"
        Me.lblGroup08.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup08.Size = New System.Drawing.Size(41, 29)
        Me.lblGroup08.TabIndex = 99
        Me.lblGroup08.Text = "Seal Air 8"
        Me.lblGroup08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picDumpTank
        '
        Me.picDumpTank.Cursor = System.Windows.Forms.Cursors.Default
        Me.picDumpTank.Image = CType(resources.GetObject("picDumpTank.Image"), System.Drawing.Image)
        Me.picDumpTank.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picDumpTank.Location = New System.Drawing.Point(264, 430)
        Me.picDumpTank.Name = "picDumpTank"
        Me.picDumpTank.Size = New System.Drawing.Size(41, 43)
        Me.picDumpTank.TabIndex = 128
        Me.picDumpTank.TabStop = False
        '
        'lblOutPressure
        '
        Me.lblOutPressure.BackColor = System.Drawing.SystemColors.Control
        Me.lblOutPressure.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutPressure.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOutPressure.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblOutPressure.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblOutPressure.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblOutPressure.Location = New System.Drawing.Point(121, 256)
        Me.lblOutPressure.Name = "lblOutPressure"
        Me.lblOutPressure.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOutPressure.Size = New System.Drawing.Size(39, 18)
        Me.lblOutPressure.TabIndex = 98
        Me.lblOutPressure.Text = "000.0"
        Me.lblOutPressure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblOutPressureTag
        '
        Me.lblOutPressureTag.BackColor = System.Drawing.Color.Transparent
        Me.lblOutPressureTag.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOutPressureTag.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblOutPressureTag.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblOutPressureTag.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblOutPressureTag.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblOutPressureTag.Location = New System.Drawing.Point(175, 253)
        Me.lblOutPressureTag.Name = "lblOutPressureTag"
        Me.lblOutPressureTag.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOutPressureTag.Size = New System.Drawing.Size(54, 43)
        Me.lblOutPressureTag.TabIndex = 97
        Me.lblOutPressureTag.Text = "Outlet Pressure  (psi)"
        Me.lblOutPressureTag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picApplCleaner
        '
        Me.picApplCleaner.Cursor = System.Windows.Forms.Cursors.Default
        Me.picApplCleaner.Image = CType(resources.GetObject("picApplCleaner.Image"), System.Drawing.Image)
        Me.picApplCleaner.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picApplCleaner.Location = New System.Drawing.Point(127, 495)
        Me.picApplCleaner.Name = "picApplCleaner"
        Me.picApplCleaner.Size = New System.Drawing.Size(60, 60)
        Me.picApplCleaner.TabIndex = 129
        Me.picApplCleaner.TabStop = False
        Me.picApplCleaner.Tag = "imlApplCleaner11"
        '
        'lblLineACA
        '
        Me.lblLineACA.BackColor = System.Drawing.Color.Black
        Me.lblLineACA.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACA.Location = New System.Drawing.Point(48, 460)
        Me.lblLineACA.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACA.Name = "lblLineACA"
        Me.lblLineACA.Size = New System.Drawing.Size(50, 3)
        Me.lblLineACA.TabIndex = 130
        '
        'lblLineACS
        '
        Me.lblLineACS.BackColor = System.Drawing.Color.Black
        Me.lblLineACS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACS.Location = New System.Drawing.Point(48, 508)
        Me.lblLineACS.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACS.Name = "lblLineACS"
        Me.lblLineACS.Size = New System.Drawing.Size(80, 3)
        Me.lblLineACS.TabIndex = 131
        '
        'lblOutPressure2
        '
        Me.lblOutPressure2.BackColor = System.Drawing.SystemColors.Control
        Me.lblOutPressure2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutPressure2.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOutPressure2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblOutPressure2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblOutPressure2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblOutPressure2.Location = New System.Drawing.Point(249, 256)
        Me.lblOutPressure2.Name = "lblOutPressure2"
        Me.lblOutPressure2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOutPressure2.Size = New System.Drawing.Size(39, 18)
        Me.lblOutPressure2.TabIndex = 135
        Me.lblOutPressure2.Text = "000.0"
        Me.lblOutPressure2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblShared01
        '
        Me.lblShared01.BackColor = System.Drawing.Color.Transparent
        Me.lblShared01.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared01.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared01.Location = New System.Drawing.Point(-3, 573)
        Me.lblShared01.Name = "lblShared01"
        Me.lblShared01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared01.Size = New System.Drawing.Size(57, 18)
        Me.lblShared01.TabIndex = 136
        Me.lblShared01.Text = "lblValve01"
        Me.lblShared01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblShared01.Visible = False
        '
        'lblShared02
        '
        Me.lblShared02.BackColor = System.Drawing.Color.Transparent
        Me.lblShared02.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared02.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared02.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared02.Location = New System.Drawing.Point(176, 97)
        Me.lblShared02.Name = "lblShared02"
        Me.lblShared02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared02.Size = New System.Drawing.Size(36, 20)
        Me.lblShared02.TabIndex = 137
        Me.lblShared02.Text = "lblValve02"
        Me.lblShared02.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGroup12
        '
        Me.lblGroup12.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup12.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup12.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup12.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup12.Location = New System.Drawing.Point(21, 296)
        Me.lblGroup12.Name = "lblGroup12"
        Me.lblGroup12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup12.Size = New System.Drawing.Size(48, 20)
        Me.lblGroup12.TabIndex = 140
        Me.lblGroup12.Text = "pDump3"
        Me.lblGroup12.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGroup11
        '
        Me.lblGroup11.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup11.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup11.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup11.Location = New System.Drawing.Point(249, 139)
        Me.lblGroup11.Name = "lblGroup11"
        Me.lblGroup11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup11.Size = New System.Drawing.Size(47, 17)
        Me.lblGroup11.TabIndex = 141
        Me.lblGroup11.Text = "lblGroup11"
        Me.lblGroup11.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblGroup10
        '
        Me.lblGroup10.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup10.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup10.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup10.Location = New System.Drawing.Point(264, 71)
        Me.lblGroup10.Name = "lblGroup10"
        Me.lblGroup10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup10.Size = New System.Drawing.Size(51, 20)
        Me.lblGroup10.TabIndex = 142
        Me.lblGroup10.Text = "Vent 10"
        Me.lblGroup10.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblGroup07
        '
        Me.lblGroup07.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup07.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup07.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup07.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup07.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup07.Location = New System.Drawing.Point(36, 219)
        Me.lblGroup07.Name = "lblGroup07"
        Me.lblGroup07.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup07.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup07.TabIndex = 143
        Me.lblGroup07.Text = "Flush 7"
        Me.lblGroup07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup15
        '
        Me.lblGroup15.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup15.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup15.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup15.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup15.Location = New System.Drawing.Point(159, 586)
        Me.lblGroup15.Name = "lblGroup15"
        Me.lblGroup15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup15.Size = New System.Drawing.Size(69, 37)
        Me.lblGroup15.TabIndex = 144
        Me.lblGroup15.Text = "Appl Cleaner Solvent 15"
        Me.lblGroup15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup15.Visible = False
        '
        'lblGroup13
        '
        Me.lblGroup13.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup13.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup13.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup13.Location = New System.Drawing.Point(24, 177)
        Me.lblGroup13.Name = "lblGroup13"
        Me.lblGroup13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup13.Size = New System.Drawing.Size(47, 20)
        Me.lblGroup13.TabIndex = 145
        Me.lblGroup13.Text = "p2T 13"
        Me.lblGroup13.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'lblAirHeaderLine4
        '
        Me.lblAirHeaderLine4.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine4.ForeColor = System.Drawing.Color.Black
        Me.lblAirHeaderLine4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine4.Location = New System.Drawing.Point(14, 460)
        Me.lblAirHeaderLine4.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine4.Name = "lblAirHeaderLine4"
        Me.lblAirHeaderLine4.Size = New System.Drawing.Size(7, 3)
        Me.lblAirHeaderLine4.TabIndex = 163
        Me.lblAirHeaderLine4.Text = "_linAirHeader_40"
        '
        'lblSolventHeader4
        '
        Me.lblSolventHeader4.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader4.Location = New System.Drawing.Point(5, 507)
        Me.lblSolventHeader4.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader4.Name = "lblSolventHeader4"
        Me.lblSolventHeader4.Size = New System.Drawing.Size(16, 3)
        Me.lblSolventHeader4.TabIndex = 164
        '
        'lblLineWashOut1
        '
        Me.lblLineWashOut1.BackColor = System.Drawing.Color.Black
        Me.lblLineWashOut1.ForeColor = System.Drawing.Color.Black
        Me.lblLineWashOut1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineWashOut1.Location = New System.Drawing.Point(100, 374)
        Me.lblLineWashOut1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineWashOut1.Name = "lblLineWashOut1"
        Me.lblLineWashOut1.Size = New System.Drawing.Size(26, 3)
        Me.lblLineWashOut1.TabIndex = 166
        '
        'lblLineSolvAir1
        '
        Me.lblLineSolvAir1.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAir1.ForeColor = System.Drawing.Color.Black
        Me.lblLineSolvAir1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAir1.Location = New System.Drawing.Point(101, 88)
        Me.lblLineSolvAir1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAir1.Name = "lblLineSolvAir1"
        Me.lblLineSolvAir1.Size = New System.Drawing.Size(32, 3)
        Me.lblLineSolvAir1.TabIndex = 167
        '
        'lblLineSolvAir2
        '
        Me.lblLineSolvAir2.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAir2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAir2.Location = New System.Drawing.Point(130, 91)
        Me.lblLineSolvAir2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAir2.Name = "lblLineSolvAir2"
        Me.lblLineSolvAir2.Size = New System.Drawing.Size(3, 24)
        Me.lblLineSolvAir2.TabIndex = 168
        '
        'lblLineColStk5
        '
        Me.lblLineColStk5.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblLineColStk5.ForeColor = System.Drawing.Color.Black
        Me.lblLineColStk5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk5.Location = New System.Drawing.Point(162, 194)
        Me.lblLineColStk5.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk5.Name = "lblLineColStk5"
        Me.lblLineColStk5.Size = New System.Drawing.Size(20, 3)
        Me.lblLineColStk5.TabIndex = 169
        '
        'lblLineBellMan1
        '
        Me.lblLineBellMan1.BackColor = System.Drawing.Color.Black
        Me.lblLineBellMan1.ForeColor = System.Drawing.Color.Black
        Me.lblLineBellMan1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineBellMan1.Location = New System.Drawing.Point(158, 374)
        Me.lblLineBellMan1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineBellMan1.Name = "lblLineBellMan1"
        Me.lblLineBellMan1.Size = New System.Drawing.Size(46, 3)
        Me.lblLineBellMan1.TabIndex = 170
        '
        'lblLinMix02
        '
        Me.lblLinMix02.BackColor = System.Drawing.Color.Black
        Me.lblLinMix02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLinMix02.Location = New System.Drawing.Point(200, 331)
        Me.lblLinMix02.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLinMix02.Name = "lblLinMix02"
        Me.lblLinMix02.Size = New System.Drawing.Size(50, 3)
        Me.lblLinMix02.TabIndex = 171
        '
        'picVersabellGearsPump01
        '
        Me.picVersabellGearsPump01.Cursor = System.Windows.Forms.Cursors.Default
        Me.picVersabellGearsPump01.Image = CType(resources.GetObject("picVersabellGearsPump01.Image"), System.Drawing.Image)
        Me.picVersabellGearsPump01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picVersabellGearsPump01.Location = New System.Drawing.Point(138, 223)
        Me.picVersabellGearsPump01.Name = "picVersabellGearsPump01"
        Me.picVersabellGearsPump01.Size = New System.Drawing.Size(49, 27)
        Me.picVersabellGearsPump01.TabIndex = 172
        Me.picVersabellGearsPump01.TabStop = False
        Me.picVersabellGearsPump01.Tag = "imlGears11"
        '
        'lblFlow
        '
        Me.lblFlow.BackColor = System.Drawing.SystemColors.Control
        Me.lblFlow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFlow.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFlow.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblFlow.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFlow.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblFlow.Location = New System.Drawing.Point(227, 527)
        Me.lblFlow.Name = "lblFlow"
        Me.lblFlow.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFlow.Size = New System.Drawing.Size(39, 18)
        Me.lblFlow.TabIndex = 175
        Me.lblFlow.Text = "000.0"
        Me.lblFlow.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblFlowTag
        '
        Me.lblFlowTag.BackColor = System.Drawing.Color.Transparent
        Me.lblFlowTag.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFlowTag.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblFlowTag.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFlowTag.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblFlowTag.Location = New System.Drawing.Point(205, 476)
        Me.lblFlowTag.Name = "lblFlowTag"
        Me.lblFlowTag.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFlowTag.Size = New System.Drawing.Size(83, 51)
        Me.lblFlowTag.TabIndex = 176
        Me.lblFlowTag.Text = "Flow Rate (cc/min)"
        Me.lblFlowTag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup26
        '
        Me.lblGroup26.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup26.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup26.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup26.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup26.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup26.Location = New System.Drawing.Point(359, 401)
        Me.lblGroup26.Name = "lblGroup26"
        Me.lblGroup26.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup26.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup26.TabIndex = 193
        Me.lblGroup26.Text = "lblGroup26"
        Me.lblGroup26.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup26.Visible = False
        '
        'lblGroup25
        '
        Me.lblGroup25.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup25.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup25.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup25.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup25.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup25.Location = New System.Drawing.Point(362, 366)
        Me.lblGroup25.Name = "lblGroup25"
        Me.lblGroup25.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup25.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup25.TabIndex = 194
        Me.lblGroup25.Text = "lblGroup25"
        Me.lblGroup25.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup25.Visible = False
        '
        'lblGroup23
        '
        Me.lblGroup23.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup23.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup23.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup23.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup23.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup23.Location = New System.Drawing.Point(359, 290)
        Me.lblGroup23.Name = "lblGroup23"
        Me.lblGroup23.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup23.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup23.TabIndex = 195
        Me.lblGroup23.Text = "lblGroup23"
        Me.lblGroup23.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup23.Visible = False
        '
        'lblGroup22
        '
        Me.lblGroup22.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup22.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup22.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup22.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup22.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup22.Location = New System.Drawing.Point(359, 252)
        Me.lblGroup22.Name = "lblGroup22"
        Me.lblGroup22.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup22.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup22.TabIndex = 196
        Me.lblGroup22.Text = "lblGroup22"
        Me.lblGroup22.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup22.Visible = False
        '
        'lblGroup21
        '
        Me.lblGroup21.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup21.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup21.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup21.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup21.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup21.Location = New System.Drawing.Point(359, 219)
        Me.lblGroup21.Name = "lblGroup21"
        Me.lblGroup21.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup21.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup21.TabIndex = 197
        Me.lblGroup21.Text = "lblGroup21"
        Me.lblGroup21.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup21.Visible = False
        '
        'lblGroup20
        '
        Me.lblGroup20.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup20.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup20.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup20.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup20.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup20.Location = New System.Drawing.Point(359, 180)
        Me.lblGroup20.Name = "lblGroup20"
        Me.lblGroup20.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup20.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup20.TabIndex = 198
        Me.lblGroup20.Text = "lblGroup20"
        Me.lblGroup20.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup20.Visible = False
        '
        'lblGroup19
        '
        Me.lblGroup19.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup19.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup19.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup19.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup19.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup19.Location = New System.Drawing.Point(359, 135)
        Me.lblGroup19.Name = "lblGroup19"
        Me.lblGroup19.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup19.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup19.TabIndex = 199
        Me.lblGroup19.Text = "lblGroup19"
        Me.lblGroup19.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup19.Visible = False
        '
        'lblGroup18
        '
        Me.lblGroup18.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup18.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup18.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup18.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup18.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup18.Location = New System.Drawing.Point(362, 97)
        Me.lblGroup18.Name = "lblGroup18"
        Me.lblGroup18.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup18.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup18.TabIndex = 200
        Me.lblGroup18.Text = "lblGroup18"
        Me.lblGroup18.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup18.Visible = False
        '
        'lblGroup17
        '
        Me.lblGroup17.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup17.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup17.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup17.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup17.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup17.Location = New System.Drawing.Point(362, 59)
        Me.lblGroup17.Name = "lblGroup17"
        Me.lblGroup17.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup17.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup17.TabIndex = 201
        Me.lblGroup17.Text = "lblGroup17"
        Me.lblGroup17.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup17.Visible = False
        '
        'lblGroup16
        '
        Me.lblGroup16.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup16.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup16.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup16.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup16.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup16.Location = New System.Drawing.Point(359, 18)
        Me.lblGroup16.Name = "lblGroup16"
        Me.lblGroup16.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup16.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup16.TabIndex = 202
        Me.lblGroup16.Text = "lblGroup16"
        Me.lblGroup16.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup16.Visible = False
        '
        'lblGroup31
        '
        Me.lblGroup31.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup31.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup31.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup31.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup31.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup31.Location = New System.Drawing.Point(359, 590)
        Me.lblGroup31.Name = "lblGroup31"
        Me.lblGroup31.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup31.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup31.TabIndex = 203
        Me.lblGroup31.Text = "lblGroup31"
        Me.lblGroup31.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup31.Visible = False
        '
        'lblGroup30
        '
        Me.lblGroup30.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup30.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup30.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup30.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup30.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup30.Location = New System.Drawing.Point(48, 517)
        Me.lblGroup30.Name = "lblGroup30"
        Me.lblGroup30.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup30.Size = New System.Drawing.Size(72, 29)
        Me.lblGroup30.TabIndex = 204
        Me.lblGroup30.Text = "ACVA 30"
        Me.lblGroup30.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup29
        '
        Me.lblGroup29.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup29.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup29.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup29.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup29.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup29.Location = New System.Drawing.Point(48, 464)
        Me.lblGroup29.Name = "lblGroup29"
        Me.lblGroup29.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup29.Size = New System.Drawing.Size(48, 44)
        Me.lblGroup29.TabIndex = 205
        Me.lblGroup29.Text = "ACS 29"
        Me.lblGroup29.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup28
        '
        Me.lblGroup28.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup28.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup28.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup28.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup28.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup28.Location = New System.Drawing.Point(48, 424)
        Me.lblGroup28.Name = "lblGroup28"
        Me.lblGroup28.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup28.Size = New System.Drawing.Size(48, 35)
        Me.lblGroup28.TabIndex = 206
        Me.lblGroup28.Text = "ACA 28"
        Me.lblGroup28.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup27
        '
        Me.lblGroup27.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup27.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup27.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup27.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup27.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup27.Location = New System.Drawing.Point(359, 444)
        Me.lblGroup27.Name = "lblGroup27"
        Me.lblGroup27.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup27.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup27.TabIndex = 207
        Me.lblGroup27.Text = "lblGroup27"
        Me.lblGroup27.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup27.Visible = False
        '
        'lblGroup24
        '
        Me.lblGroup24.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup24.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup24.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup24.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup24.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup24.Location = New System.Drawing.Point(362, 331)
        Me.lblGroup24.Name = "lblGroup24"
        Me.lblGroup24.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup24.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup24.TabIndex = 208
        Me.lblGroup24.Text = "lblGroup24"
        Me.lblGroup24.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup24.Visible = False
        '
        'lblLineSolvAirOut1
        '
        Me.lblLineSolvAirOut1.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAirOut1.ForeColor = System.Drawing.Color.Black
        Me.lblLineSolvAirOut1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAirOut1.Location = New System.Drawing.Point(99, 208)
        Me.lblLineSolvAirOut1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAirOut1.Name = "lblLineSolvAirOut1"
        Me.lblLineSolvAirOut1.Size = New System.Drawing.Size(3, 120)
        Me.lblLineSolvAirOut1.TabIndex = 209
        '
        'lblLineACA2
        '
        Me.lblLineACA2.BackColor = System.Drawing.Color.Black
        Me.lblLineACA2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACA2.Location = New System.Drawing.Point(95, 460)
        Me.lblLineACA2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACA2.Name = "lblLineACA2"
        Me.lblLineACA2.Size = New System.Drawing.Size(3, 45)
        Me.lblLineACA2.TabIndex = 213
        '
        'lblLineACA3
        '
        Me.lblLineACA3.BackColor = System.Drawing.Color.Black
        Me.lblLineACA3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACA3.Location = New System.Drawing.Point(97, 502)
        Me.lblLineACA3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACA3.Name = "lblLineACA3"
        Me.lblLineACA3.Size = New System.Drawing.Size(30, 3)
        Me.lblLineACA3.TabIndex = 214
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Blue
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(14, 546)
        Me.Label1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(7, 3)
        Me.Label1.TabIndex = 215
        Me.Label1.Text = "_linAirHeader_40"
        '
        'lblLineACVA
        '
        Me.lblLineACVA.BackColor = System.Drawing.Color.Black
        Me.lblLineACVA.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACVA.Location = New System.Drawing.Point(48, 546)
        Me.lblLineACVA.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACVA.Name = "lblLineACVA"
        Me.lblLineACVA.Size = New System.Drawing.Size(80, 3)
        Me.lblLineACVA.TabIndex = 216
        '
        'picVersabellGearsPump02
        '
        Me.picVersabellGearsPump02.Cursor = System.Windows.Forms.Cursors.Default
        Me.picVersabellGearsPump02.Image = CType(resources.GetObject("picVersabellGearsPump02.Image"), System.Drawing.Image)
        Me.picVersabellGearsPump02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picVersabellGearsPump02.Location = New System.Drawing.Point(222, 223)
        Me.picVersabellGearsPump02.Name = "picVersabellGearsPump02"
        Me.picVersabellGearsPump02.Size = New System.Drawing.Size(49, 27)
        Me.picVersabellGearsPump02.TabIndex = 217
        Me.picVersabellGearsPump02.TabStop = False
        Me.picVersabellGearsPump02.Tag = "imlGears11"
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(237, 18)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(3, 76)
        Me.Label2.TabIndex = 218
        '
        'lblSolventHeader5
        '
        Me.lblSolventHeader5.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader5.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader5.Location = New System.Drawing.Point(6, 237)
        Me.lblSolventHeader5.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader5.Name = "lblSolventHeader5"
        Me.lblSolventHeader5.Size = New System.Drawing.Size(100, 3)
        Me.lblSolventHeader5.TabIndex = 219
        '
        'lblLineWashOut2
        '
        Me.lblLineWashOut2.BackColor = System.Drawing.Color.Black
        Me.lblLineWashOut2.ForeColor = System.Drawing.Color.Black
        Me.lblLineWashOut2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineWashOut2.Location = New System.Drawing.Point(99, 356)
        Me.lblLineWashOut2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineWashOut2.Name = "lblLineWashOut2"
        Me.lblLineWashOut2.Size = New System.Drawing.Size(3, 37)
        Me.lblLineWashOut2.TabIndex = 220
        '
        'lblSolventHeader6
        '
        Me.lblSolventHeader6.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader6.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader6.Location = New System.Drawing.Point(260, 55)
        Me.lblSolventHeader6.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader6.Name = "lblSolventHeader6"
        Me.lblSolventHeader6.Size = New System.Drawing.Size(3, 40)
        Me.lblSolventHeader6.TabIndex = 221
        '
        'linHdrStack01
        '
        Me.linHdrStack01.BackColor = System.Drawing.Color.Black
        Me.linHdrStack01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.linHdrStack01.Location = New System.Drawing.Point(238, 123)
        Me.linHdrStack01.MinimumSize = New System.Drawing.Size(3, 3)
        Me.linHdrStack01.Name = "linHdrStack01"
        Me.linHdrStack01.Size = New System.Drawing.Size(24, 3)
        Me.linHdrStack01.TabIndex = 222
        '
        'linHdrStack02
        '
        Me.linHdrStack02.BackColor = System.Drawing.Color.Black
        Me.linHdrStack02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.linHdrStack02.Location = New System.Drawing.Point(245, 123)
        Me.linHdrStack02.MinimumSize = New System.Drawing.Size(3, 3)
        Me.linHdrStack02.Name = "linHdrStack02"
        Me.linHdrStack02.Size = New System.Drawing.Size(3, 177)
        Me.linHdrStack02.TabIndex = 223
        '
        'lblLineSolvAirOut2
        '
        Me.lblLineSolvAirOut2.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAirOut2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAirOut2.Location = New System.Drawing.Point(90, 316)
        Me.lblLineSolvAirOut2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAirOut2.Name = "lblLineSolvAirOut2"
        Me.lblLineSolvAirOut2.Size = New System.Drawing.Size(11, 3)
        Me.lblLineSolvAirOut2.TabIndex = 224
        '
        'lblLineDump3_1
        '
        Me.lblLineDump3_1.BackColor = System.Drawing.Color.Black
        Me.lblLineDump3_1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineDump3_1.Location = New System.Drawing.Point(21, 316)
        Me.lblLineDump3_1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineDump3_1.Name = "lblLineDump3_1"
        Me.lblLineDump3_1.Size = New System.Drawing.Size(41, 3)
        Me.lblLineDump3_1.TabIndex = 225
        '
        'lblLineColStk4
        '
        Me.lblLineColStk4.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk4.ForeColor = System.Drawing.Color.Black
        Me.lblLineColStk4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk4.Location = New System.Drawing.Point(161, 300)
        Me.lblLineColStk4.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk4.Name = "lblLineColStk4"
        Me.lblLineColStk4.Size = New System.Drawing.Size(40, 3)
        Me.lblLineColStk4.TabIndex = 227
        '
        'linHdrStack03
        '
        Me.linHdrStack03.BackColor = System.Drawing.Color.Black
        Me.linHdrStack03.ForeColor = System.Drawing.Color.Black
        Me.linHdrStack03.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.linHdrStack03.Location = New System.Drawing.Point(202, 300)
        Me.linHdrStack03.MinimumSize = New System.Drawing.Size(3, 3)
        Me.linHdrStack03.Name = "linHdrStack03"
        Me.linHdrStack03.Size = New System.Drawing.Size(46, 3)
        Me.linHdrStack03.TabIndex = 228
        '
        'lblLinMix01
        '
        Me.lblLinMix01.BackColor = System.Drawing.Color.Black
        Me.lblLinMix01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLinMix01.Location = New System.Drawing.Point(200, 300)
        Me.lblLinMix01.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLinMix01.Name = "lblLinMix01"
        Me.lblLinMix01.Size = New System.Drawing.Size(3, 50)
        Me.lblLinMix01.TabIndex = 229
        '
        'lblOutPressure2Tag
        '
        Me.lblOutPressure2Tag.BackColor = System.Drawing.Color.Transparent
        Me.lblOutPressure2Tag.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOutPressure2Tag.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblOutPressure2Tag.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblOutPressure2Tag.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblOutPressure2Tag.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblOutPressure2Tag.Location = New System.Drawing.Point(350, 495)
        Me.lblOutPressure2Tag.Name = "lblOutPressure2Tag"
        Me.lblOutPressure2Tag.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOutPressure2Tag.Size = New System.Drawing.Size(54, 43)
        Me.lblOutPressure2Tag.TabIndex = 230
        Me.lblOutPressure2Tag.Text = "Outlet Pressure  (psi)"
        Me.lblOutPressure2Tag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblSolventHeader7
        '
        Me.lblSolventHeader7.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader7.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader7.Location = New System.Drawing.Point(299, 48)
        Me.lblSolventHeader7.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader7.Name = "lblSolventHeader7"
        Me.lblSolventHeader7.Size = New System.Drawing.Size(3, 112)
        Me.lblSolventHeader7.TabIndex = 231
        '
        'lblLineFlush2_1
        '
        Me.lblLineFlush2_1.BackColor = System.Drawing.Color.Black
        Me.lblLineFlush2_1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineFlush2_1.Location = New System.Drawing.Point(299, 189)
        Me.lblLineFlush2_1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineFlush2_1.Name = "lblLineFlush2_1"
        Me.lblLineFlush2_1.Size = New System.Drawing.Size(3, 49)
        Me.lblLineFlush2_1.TabIndex = 232
        '
        'lblLineFlush2_2
        '
        Me.lblLineFlush2_2.BackColor = System.Drawing.Color.Black
        Me.lblLineFlush2_2.ForeColor = System.Drawing.Color.Black
        Me.lblLineFlush2_2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineFlush2_2.Location = New System.Drawing.Point(269, 235)
        Me.lblLineFlush2_2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineFlush2_2.Name = "lblLineFlush2_2"
        Me.lblLineFlush2_2.Size = New System.Drawing.Size(33, 3)
        Me.lblLineFlush2_2.TabIndex = 233
        '
        'lblLineFlush
        '
        Me.lblLineFlush.BackColor = System.Drawing.Color.Black
        Me.lblLineFlush.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineFlush.Location = New System.Drawing.Point(135, 238)
        Me.lblLineFlush.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineFlush.Name = "lblLineFlush"
        Me.lblLineFlush.Size = New System.Drawing.Size(3, 3)
        Me.lblLineFlush.TabIndex = 234
        '
        'UctrlGroupValve31
        '
        Me.UctrlGroupValve31.AutoFit = True
        Me.UctrlGroupValve31.Location = New System.Drawing.Point(321, 587)
        Me.UctrlGroupValve31.Name = "UctrlGroupValve31"
        Me.UctrlGroupValve31.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve31.TabIndex = 192
        Me.UctrlGroupValve31.Tag = "30"
        Me.UctrlGroupValve31.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve31.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve31.ValvState = False
        Me.UctrlGroupValve31.Visible = False
        '
        'UctrlGroupValve25
        '
        Me.UctrlGroupValve25.AutoFit = True
        Me.UctrlGroupValve25.Location = New System.Drawing.Point(321, 361)
        Me.UctrlGroupValve25.Name = "UctrlGroupValve25"
        Me.UctrlGroupValve25.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve25.TabIndex = 191
        Me.UctrlGroupValve25.Tag = "25"
        Me.UctrlGroupValve25.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve25.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve25.ValvState = False
        Me.UctrlGroupValve25.Visible = False
        '
        'UctrlGroupValve30
        '
        Me.UctrlGroupValve30.AutoFit = True
        Me.UctrlGroupValve30.Location = New System.Drawing.Point(21, 523)
        Me.UctrlGroupValve30.Name = "UctrlGroupValve30"
        Me.UctrlGroupValve30.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve30.TabIndex = 190
        Me.UctrlGroupValve30.Tag = "30"
        Me.UctrlGroupValve30.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve30.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve30.ValvState = False
        '
        'UctrlGroupValve29
        '
        Me.UctrlGroupValve29.AutoFit = True
        Me.UctrlGroupValve29.Location = New System.Drawing.Point(21, 485)
        Me.UctrlGroupValve29.Name = "UctrlGroupValve29"
        Me.UctrlGroupValve29.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve29.TabIndex = 189
        Me.UctrlGroupValve29.Tag = "29"
        Me.UctrlGroupValve29.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve29.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve29.ValvState = False
        '
        'UctrlGroupValve28
        '
        Me.UctrlGroupValve28.AutoFit = True
        Me.UctrlGroupValve28.Location = New System.Drawing.Point(21, 437)
        Me.UctrlGroupValve28.Name = "UctrlGroupValve28"
        Me.UctrlGroupValve28.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve28.TabIndex = 188
        Me.UctrlGroupValve28.Tag = "28"
        Me.UctrlGroupValve28.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve28.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve28.ValvState = False
        '
        'UctrlGroupValve27
        '
        Me.UctrlGroupValve27.AutoFit = True
        Me.UctrlGroupValve27.Location = New System.Drawing.Point(321, 441)
        Me.UctrlGroupValve27.Name = "UctrlGroupValve27"
        Me.UctrlGroupValve27.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve27.TabIndex = 187
        Me.UctrlGroupValve27.Tag = "27"
        Me.UctrlGroupValve27.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve27.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve27.ValvState = False
        Me.UctrlGroupValve27.Visible = False
        '
        'UctrlGroupValve24
        '
        Me.UctrlGroupValve24.AutoFit = True
        Me.UctrlGroupValve24.Location = New System.Drawing.Point(321, 323)
        Me.UctrlGroupValve24.Name = "UctrlGroupValve24"
        Me.UctrlGroupValve24.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve24.TabIndex = 186
        Me.UctrlGroupValve24.Tag = "24"
        Me.UctrlGroupValve24.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve24.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve24.ValvState = False
        Me.UctrlGroupValve24.Visible = False
        '
        'UctrlGroupValve23
        '
        Me.UctrlGroupValve23.AutoFit = True
        Me.UctrlGroupValve23.Location = New System.Drawing.Point(321, 285)
        Me.UctrlGroupValve23.Name = "UctrlGroupValve23"
        Me.UctrlGroupValve23.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve23.TabIndex = 185
        Me.UctrlGroupValve23.Tag = "23"
        Me.UctrlGroupValve23.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve23.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve23.ValvState = False
        Me.UctrlGroupValve23.Visible = False
        '
        'UctrlGroupValve22
        '
        Me.UctrlGroupValve22.AutoFit = True
        Me.UctrlGroupValve22.Location = New System.Drawing.Point(321, 246)
        Me.UctrlGroupValve22.Name = "UctrlGroupValve22"
        Me.UctrlGroupValve22.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve22.TabIndex = 184
        Me.UctrlGroupValve22.Tag = "22"
        Me.UctrlGroupValve22.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve22.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve22.ValvState = False
        Me.UctrlGroupValve22.Visible = False
        '
        'UctrlGroupValve20
        '
        Me.UctrlGroupValve20.AutoFit = True
        Me.UctrlGroupValve20.Location = New System.Drawing.Point(321, 170)
        Me.UctrlGroupValve20.Name = "UctrlGroupValve20"
        Me.UctrlGroupValve20.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve20.TabIndex = 183
        Me.UctrlGroupValve20.Tag = "20"
        Me.UctrlGroupValve20.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve20.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve20.ValvState = False
        Me.UctrlGroupValve20.Visible = False
        '
        'UctrlGroupValve19
        '
        Me.UctrlGroupValve19.AutoFit = True
        Me.UctrlGroupValve19.Location = New System.Drawing.Point(321, 132)
        Me.UctrlGroupValve19.Name = "UctrlGroupValve19"
        Me.UctrlGroupValve19.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve19.TabIndex = 182
        Me.UctrlGroupValve19.Tag = "19"
        Me.UctrlGroupValve19.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve19.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve19.ValvState = False
        Me.UctrlGroupValve19.Visible = False
        '
        'UctrlGroupValve18
        '
        Me.UctrlGroupValve18.AutoFit = True
        Me.UctrlGroupValve18.Location = New System.Drawing.Point(321, 94)
        Me.UctrlGroupValve18.Name = "UctrlGroupValve18"
        Me.UctrlGroupValve18.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve18.TabIndex = 181
        Me.UctrlGroupValve18.Tag = "18"
        Me.UctrlGroupValve18.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve18.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve18.ValvState = False
        Me.UctrlGroupValve18.Visible = False
        '
        'UctrlGroupValve17
        '
        Me.UctrlGroupValve17.AutoFit = True
        Me.UctrlGroupValve17.Location = New System.Drawing.Point(321, 56)
        Me.UctrlGroupValve17.Name = "UctrlGroupValve17"
        Me.UctrlGroupValve17.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve17.TabIndex = 180
        Me.UctrlGroupValve17.Tag = "17"
        Me.UctrlGroupValve17.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve17.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve17.ValvState = False
        Me.UctrlGroupValve17.Visible = False
        '
        'UctrlGroupValve21
        '
        Me.UctrlGroupValve21.AutoFit = True
        Me.UctrlGroupValve21.Location = New System.Drawing.Point(321, 208)
        Me.UctrlGroupValve21.Name = "UctrlGroupValve21"
        Me.UctrlGroupValve21.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve21.TabIndex = 179
        Me.UctrlGroupValve21.Tag = "21"
        Me.UctrlGroupValve21.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve21.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve21.ValvState = False
        Me.UctrlGroupValve21.Visible = False
        '
        'UctrlGroupValve16
        '
        Me.UctrlGroupValve16.AutoFit = True
        Me.UctrlGroupValve16.Location = New System.Drawing.Point(321, 15)
        Me.UctrlGroupValve16.Name = "UctrlGroupValve16"
        Me.UctrlGroupValve16.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve16.TabIndex = 178
        Me.UctrlGroupValve16.Tag = "16"
        Me.UctrlGroupValve16.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve16.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve16.ValvState = False
        Me.UctrlGroupValve16.Visible = False
        '
        'UctrlGroupValve26
        '
        Me.UctrlGroupValve26.AutoFit = True
        Me.UctrlGroupValve26.Location = New System.Drawing.Point(321, 398)
        Me.UctrlGroupValve26.Name = "UctrlGroupValve26"
        Me.UctrlGroupValve26.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve26.TabIndex = 177
        Me.UctrlGroupValve26.Tag = "26"
        Me.UctrlGroupValve26.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve26.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve26.ValvState = False
        Me.UctrlGroupValve26.Visible = False
        '
        'UctrlGroupValve14
        '
        Me.UctrlGroupValve14.AutoFit = True
        Me.UctrlGroupValve14.Location = New System.Drawing.Point(76, 327)
        Me.UctrlGroupValve14.Name = "UctrlGroupValve14"
        Me.UctrlGroupValve14.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve14.TabIndex = 162
        Me.UctrlGroupValve14.Tag = "14"
        Me.UctrlGroupValve14.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve14.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve14.ValvState = False
        '
        'UctrlSharedValve0
        '
        Me.UctrlSharedValve0.AutoFit = True
        Me.UctrlSharedValve0.Location = New System.Drawing.Point(149, 393)
        Me.UctrlSharedValve0.Name = "UctrlSharedValve0"
        Me.UctrlSharedValve0.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve0.TabIndex = 165
        Me.UctrlSharedValve0.Tag = "0"
        Me.UctrlSharedValve0.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve0.ValveType = uctrlValve.eValveType.HorzRight
        Me.UctrlSharedValve0.ValvState = False
        '
        'UctrlSharedValve0b
        '
        Me.UctrlSharedValve0b.AutoFit = True
        Me.UctrlSharedValve0b.Location = New System.Drawing.Point(126, 424)
        Me.UctrlSharedValve0b.Name = "UctrlSharedValve0b"
        Me.UctrlSharedValve0b.Size = New System.Drawing.Size(63, 35)
        Me.UctrlSharedValve0b.TabIndex = 132
        Me.UctrlSharedValve0b.Tag = "0"
        Me.UctrlSharedValve0b.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve0b.ValveType = uctrlValve.eValveType.BellCup
        Me.UctrlSharedValve0b.ValvState = False
        '
        'UctrlGroupValve13
        '
        Me.UctrlGroupValve13.AutoFit = True
        Me.UctrlGroupValve13.Location = New System.Drawing.Point(76, 177)
        Me.UctrlGroupValve13.Name = "UctrlGroupValve13"
        Me.UctrlGroupValve13.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve13.TabIndex = 161
        Me.UctrlGroupValve13.Tag = "13"
        Me.UctrlGroupValve13.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve13.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve13.ValvState = False
        '
        'UctrlGroupValve15
        '
        Me.UctrlGroupValve15.AutoFit = True
        Me.UctrlGroupValve15.AutoSize = True
        Me.UctrlGroupValve15.Location = New System.Drawing.Point(115, 591)
        Me.UctrlGroupValve15.Name = "UctrlGroupValve15"
        Me.UctrlGroupValve15.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve15.TabIndex = 159
        Me.UctrlGroupValve15.Tag = "15"
        Me.UctrlGroupValve15.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve15.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve15.ValvState = False
        Me.UctrlGroupValve15.Visible = False
        '
        'UctrlGroupValve10
        '
        Me.UctrlGroupValve10.AutoFit = True
        Me.UctrlGroupValve10.Location = New System.Drawing.Point(254, 94)
        Me.UctrlGroupValve10.Name = "UctrlGroupValve10"
        Me.UctrlGroupValve10.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve10.TabIndex = 158
        Me.UctrlGroupValve10.Tag = "10"
        Me.UctrlGroupValve10.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve10.ValveType = uctrlValve.eValveType.HorzRight
        Me.UctrlGroupValve10.ValvState = False
        '
        'UctrlGroupValve11
        '
        Me.UctrlGroupValve11.AutoFit = True
        Me.UctrlGroupValve11.Location = New System.Drawing.Point(276, 159)
        Me.UctrlGroupValve11.Name = "UctrlGroupValve11"
        Me.UctrlGroupValve11.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve11.TabIndex = 157
        Me.UctrlGroupValve11.Tag = "11"
        Me.UctrlGroupValve11.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve11.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve11.ValvState = False
        '
        'UctrlGroupValve12
        '
        Me.UctrlGroupValve12.AutoFit = True
        Me.UctrlGroupValve12.AutoSize = True
        Me.UctrlGroupValve12.BackColor = System.Drawing.Color.Transparent
        Me.UctrlGroupValve12.Location = New System.Drawing.Point(61, 293)
        Me.UctrlGroupValve12.Name = "UctrlGroupValve12"
        Me.UctrlGroupValve12.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve12.TabIndex = 156
        Me.UctrlGroupValve12.Tag = "12"
        Me.UctrlGroupValve12.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve12.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve12.ValvState = False
        '
        'UctrlGroupValve9
        '
        Me.UctrlGroupValve9.AutoFit = True
        Me.UctrlGroupValve9.Location = New System.Drawing.Point(180, 171)
        Me.UctrlGroupValve9.Name = "UctrlGroupValve9"
        Me.UctrlGroupValve9.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve9.TabIndex = 155
        Me.UctrlGroupValve9.Tag = "9"
        Me.UctrlGroupValve9.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve9.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve9.ValvState = False
        '
        'UctrlGroupValve8
        '
        Me.UctrlGroupValve8.AutoFit = True
        Me.UctrlGroupValve8.Location = New System.Drawing.Point(22, 243)
        Me.UctrlGroupValve8.Name = "UctrlGroupValve8"
        Me.UctrlGroupValve8.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve8.TabIndex = 154
        Me.UctrlGroupValve8.Tag = "8"
        Me.UctrlGroupValve8.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve8.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve8.ValvState = False
        '
        'UctrlGroupValve7
        '
        Me.UctrlGroupValve7.AutoFit = True
        Me.UctrlGroupValve7.Location = New System.Drawing.Point(105, 215)
        Me.UctrlGroupValve7.Name = "UctrlGroupValve7"
        Me.UctrlGroupValve7.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve7.TabIndex = 153
        Me.UctrlGroupValve7.Tag = "7"
        Me.UctrlGroupValve7.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve7.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve7.ValvState = False
        '
        'UctrlGroupValve6
        '
        Me.UctrlGroupValve6.AutoFit = True
        Me.UctrlGroupValve6.Location = New System.Drawing.Point(248, 308)
        Me.UctrlGroupValve6.Name = "UctrlGroupValve6"
        Me.UctrlGroupValve6.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve6.TabIndex = 152
        Me.UctrlGroupValve6.Tag = "6"
        Me.UctrlGroupValve6.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve6.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve6.ValvState = False
        '
        'UctrlGroupValve5
        '
        Me.UctrlGroupValve5.AutoFit = True
        Me.UctrlGroupValve5.Location = New System.Drawing.Point(107, 115)
        Me.UctrlGroupValve5.Name = "UctrlGroupValve5"
        Me.UctrlGroupValve5.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve5.TabIndex = 151
        Me.UctrlGroupValve5.Tag = "5"
        Me.UctrlGroupValve5.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve5.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve5.ValvState = False
        '
        'UctrlGroupValve4
        '
        Me.UctrlGroupValve4.AutoFit = True
        Me.UctrlGroupValve4.Location = New System.Drawing.Point(70, 65)
        Me.UctrlGroupValve4.Name = "UctrlGroupValve4"
        Me.UctrlGroupValve4.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve4.TabIndex = 150
        Me.UctrlGroupValve4.Tag = "4"
        Me.UctrlGroupValve4.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve4.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve4.ValvState = False
        '
        'UctrlGroupValve3
        '
        Me.UctrlGroupValve3.AutoFit = True
        Me.UctrlGroupValve3.Location = New System.Drawing.Point(70, 121)
        Me.UctrlGroupValve3.Name = "UctrlGroupValve3"
        Me.UctrlGroupValve3.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve3.TabIndex = 149
        Me.UctrlGroupValve3.Tag = "3"
        Me.UctrlGroupValve3.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve3.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve3.ValvState = False
        '
        'UctrlGroupValve2
        '
        Me.UctrlGroupValve2.AutoFit = True
        Me.UctrlGroupValve2.Location = New System.Drawing.Point(76, 393)
        Me.UctrlGroupValve2.Name = "UctrlGroupValve2"
        Me.UctrlGroupValve2.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve2.TabIndex = 148
        Me.UctrlGroupValve2.Tag = "2"
        Me.UctrlGroupValve2.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve2.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve2.ValvState = False
        '
        'UctrlGroupValve1
        '
        Me.UctrlGroupValve1.AutoFit = True
        Me.UctrlGroupValve1.Location = New System.Drawing.Point(125, 351)
        Me.UctrlGroupValve1.Name = "UctrlGroupValve1"
        Me.UctrlGroupValve1.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve1.TabIndex = 147
        Me.UctrlGroupValve1.Tag = "1"
        Me.UctrlGroupValve1.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve1.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve1.ValvState = False
        '
        'UctrlSharedValve0a
        '
        Me.UctrlSharedValve0a.AutoFit = True
        Me.UctrlSharedValve0a.Location = New System.Drawing.Point(115, 460)
        Me.UctrlSharedValve0a.Name = "UctrlSharedValve0a"
        Me.UctrlSharedValve0a.Size = New System.Drawing.Size(85, 45)
        Me.UctrlSharedValve0a.TabIndex = 146
        Me.UctrlSharedValve0a.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve0a.ValveType = uctrlValve.eValveType.SprayPattern
        Me.UctrlSharedValve0a.ValvState = False
        '
        'UctrlGroupValve0
        '
        Me.UctrlGroupValve0.AutoFit = True
        Me.UctrlGroupValve0.Location = New System.Drawing.Point(178, 345)
        Me.UctrlGroupValve0.Name = "UctrlGroupValve0"
        Me.UctrlGroupValve0.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve0.TabIndex = 139
        Me.UctrlGroupValve0.Tag = "0"
        Me.UctrlGroupValve0.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve0.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve0.ValvState = False
        '
        'UctrlSharedValve3
        '
        Me.UctrlSharedValve3.AutoFit = True
        Me.UctrlSharedValve3.Location = New System.Drawing.Point(149, 62)
        Me.UctrlSharedValve3.Name = "UctrlSharedValve3"
        Me.UctrlSharedValve3.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve3.TabIndex = 138
        Me.UctrlSharedValve3.Tag = "3"
        Me.UctrlSharedValve3.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve3.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlSharedValve3.ValvState = False
        '
        'UctrlSharedValve1
        '
        Me.UctrlSharedValve1.AutoFit = True
        Me.UctrlSharedValve1.Location = New System.Drawing.Point(5, 594)
        Me.UctrlSharedValve1.Name = "UctrlSharedValve1"
        Me.UctrlSharedValve1.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve1.TabIndex = 134
        Me.UctrlSharedValve1.Tag = "1"
        Me.UctrlSharedValve1.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve1.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlSharedValve1.ValvState = False
        Me.UctrlSharedValve1.Visible = False
        '
        'UctrlSharedValve2
        '
        Me.UctrlSharedValve2.AutoFit = True
        Me.UctrlSharedValve2.AutoSize = True
        Me.UctrlSharedValve2.Location = New System.Drawing.Point(214, 94)
        Me.UctrlSharedValve2.Name = "UctrlSharedValve2"
        Me.UctrlSharedValve2.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve2.TabIndex = 133
        Me.UctrlSharedValve2.Tag = "2"
        Me.UctrlSharedValve2.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve2.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlSharedValve2.ValvState = False
        '
        'lblLineDump3_2
        '
        Me.lblLineDump3_2.BackColor = System.Drawing.Color.Black
        Me.lblLineDump3_2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineDump3_2.Location = New System.Drawing.Point(21, 316)
        Me.lblLineDump3_2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineDump3_2.Name = "lblLineDump3_2"
        Me.lblLineDump3_2.Size = New System.Drawing.Size(3, 52)
        Me.lblLineDump3_2.TabIndex = 235
        '
        'lblInPressureTag
        '
        Me.lblInPressureTag.BackColor = System.Drawing.Color.Transparent
        Me.lblInPressureTag.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblInPressureTag.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblInPressureTag.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblInPressureTag.ImageAlign = System.Drawing.ContentAlignment.MiddleRight
        Me.lblInPressureTag.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInPressureTag.Location = New System.Drawing.Point(164, 198)
        Me.lblInPressureTag.Name = "lblInPressureTag"
        Me.lblInPressureTag.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblInPressureTag.Size = New System.Drawing.Size(82, 43)
        Me.lblInPressureTag.TabIndex = 236
        Me.lblInPressureTag.Text = "Inlet Pressure  (psi)"
        Me.lblInPressureTag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblInPressure2
        '
        Me.lblInPressure2.BackColor = System.Drawing.SystemColors.Control
        Me.lblInPressure2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblInPressure2.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblInPressure2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblInPressure2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblInPressure2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInPressure2.Location = New System.Drawing.Point(249, 198)
        Me.lblInPressure2.Name = "lblInPressure2"
        Me.lblInPressure2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblInPressure2.Size = New System.Drawing.Size(39, 18)
        Me.lblInPressure2.TabIndex = 238
        Me.lblInPressure2.Text = "000.0"
        Me.lblInPressure2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblInPressure
        '
        Me.lblInPressure.BackColor = System.Drawing.SystemColors.Control
        Me.lblInPressure.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblInPressure.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblInPressure.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblInPressure.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblInPressure.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblInPressure.Location = New System.Drawing.Point(121, 198)
        Me.lblInPressure.Name = "lblInPressure"
        Me.lblInPressure.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblInPressure.Size = New System.Drawing.Size(39, 18)
        Me.lblInPressure.TabIndex = 237
        Me.lblInPressure.Text = "000.0"
        Me.lblInPressure.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'uctrlVersabell2_2k
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.Controls.Add(Me.lblInPressure2)
        Me.Controls.Add(Me.lblInPressure)
        Me.Controls.Add(Me.lblGroup12)
        Me.Controls.Add(Me.lblLineDump3_2)
        Me.Controls.Add(Me.lblLineFlush)
        Me.Controls.Add(Me.lblLineFlush2_2)
        Me.Controls.Add(Me.lblLineFlush2_1)
        Me.Controls.Add(Me.lblSolventHeader7)
        Me.Controls.Add(Me.lblOutPressure2Tag)
        Me.Controls.Add(Me.lblLinMix01)
        Me.Controls.Add(Me.linHdrStack03)
        Me.Controls.Add(Me.lblLineColStk4)
        Me.Controls.Add(Me.lblLineDump3_1)
        Me.Controls.Add(Me.lblLineSolvAirOut2)
        Me.Controls.Add(Me.linHdrStack02)
        Me.Controls.Add(Me.linHdrStack01)
        Me.Controls.Add(Me.lblSolventHeader6)
        Me.Controls.Add(Me.lblLineWashOut2)
        Me.Controls.Add(Me.lblSolventHeader5)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.picVersabellGearsPump02)
        Me.Controls.Add(Me.lblLineACVA)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblLineACA3)
        Me.Controls.Add(Me.lblLineACA2)
        Me.Controls.Add(Me.lblLineSolvAirOut1)
        Me.Controls.Add(Me.lblShared00)
        Me.Controls.Add(Me.lblGroup24)
        Me.Controls.Add(Me.lblGroup27)
        Me.Controls.Add(Me.lblGroup29)
        Me.Controls.Add(Me.lblGroup30)
        Me.Controls.Add(Me.lblGroup31)
        Me.Controls.Add(Me.lblGroup16)
        Me.Controls.Add(Me.lblGroup17)
        Me.Controls.Add(Me.lblGroup18)
        Me.Controls.Add(Me.lblGroup19)
        Me.Controls.Add(Me.lblGroup20)
        Me.Controls.Add(Me.lblGroup21)
        Me.Controls.Add(Me.lblGroup22)
        Me.Controls.Add(Me.lblGroup23)
        Me.Controls.Add(Me.lblGroup25)
        Me.Controls.Add(Me.lblGroup26)
        Me.Controls.Add(Me.UctrlGroupValve31)
        Me.Controls.Add(Me.UctrlGroupValve25)
        Me.Controls.Add(Me.UctrlGroupValve30)
        Me.Controls.Add(Me.UctrlGroupValve29)
        Me.Controls.Add(Me.UctrlGroupValve28)
        Me.Controls.Add(Me.UctrlGroupValve27)
        Me.Controls.Add(Me.UctrlGroupValve24)
        Me.Controls.Add(Me.UctrlGroupValve23)
        Me.Controls.Add(Me.UctrlGroupValve22)
        Me.Controls.Add(Me.UctrlGroupValve20)
        Me.Controls.Add(Me.UctrlGroupValve19)
        Me.Controls.Add(Me.UctrlGroupValve18)
        Me.Controls.Add(Me.UctrlGroupValve17)
        Me.Controls.Add(Me.UctrlGroupValve21)
        Me.Controls.Add(Me.UctrlGroupValve16)
        Me.Controls.Add(Me.UctrlGroupValve26)
        Me.Controls.Add(Me.UctrlGroupValve14)
        Me.Controls.Add(Me.lblLineACA)
        Me.Controls.Add(Me.picApplCleaner)
        Me.Controls.Add(Me.lblLineColStk3)
        Me.Controls.Add(Me.picVersabellGearsPump01)
        Me.Controls.Add(Me.lblFlow)
        Me.Controls.Add(Me.lblLineDump1)
        Me.Controls.Add(Me.lblLinMix02)
        Me.Controls.Add(Me.lblLineBellMan1)
        Me.Controls.Add(Me.UctrlSharedValve0)
        Me.Controls.Add(Me.lblLineColStk5)
        Me.Controls.Add(Me.lblLineSolvAir2)
        Me.Controls.Add(Me.lblLineColStk2)
        Me.Controls.Add(Me.lblLineSolvAir1)
        Me.Controls.Add(Me.lblLineWashOut1)
        Me.Controls.Add(Me.lblLineBellMan2)
        Me.Controls.Add(Me.UctrlSharedValve0b)
        Me.Controls.Add(Me.lblSolventHeader4)
        Me.Controls.Add(Me.lblAirHeaderLine4)
        Me.Controls.Add(Me.lblLineSealAir)
        Me.Controls.Add(Me.lblLineSolvAir)
        Me.Controls.Add(Me.UctrlGroupValve13)
        Me.Controls.Add(Me.UctrlGroupValve15)
        Me.Controls.Add(Me.UctrlGroupValve10)
        Me.Controls.Add(Me.UctrlGroupValve11)
        Me.Controls.Add(Me.UctrlGroupValve12)
        Me.Controls.Add(Me.UctrlGroupValve9)
        Me.Controls.Add(Me.UctrlGroupValve8)
        Me.Controls.Add(Me.UctrlGroupValve7)
        Me.Controls.Add(Me.UctrlGroupValve6)
        Me.Controls.Add(Me.UctrlGroupValve5)
        Me.Controls.Add(Me.UctrlGroupValve4)
        Me.Controls.Add(Me.UctrlGroupValve3)
        Me.Controls.Add(Me.UctrlGroupValve2)
        Me.Controls.Add(Me.UctrlGroupValve1)
        Me.Controls.Add(Me.UctrlSharedValve0a)
        Me.Controls.Add(Me.lblGroup13)
        Me.Controls.Add(Me.lblGroup15)
        Me.Controls.Add(Me.lblGroup07)
        Me.Controls.Add(Me.lblGroup10)
        Me.Controls.Add(Me.lblGroup11)
        Me.Controls.Add(Me.UctrlGroupValve0)
        Me.Controls.Add(Me.UctrlSharedValve3)
        Me.Controls.Add(Me.lblShared02)
        Me.Controls.Add(Me.lblShared01)
        Me.Controls.Add(Me.lblOutPressure2)
        Me.Controls.Add(Me.UctrlSharedValve1)
        Me.Controls.Add(Me.UctrlSharedValve2)
        Me.Controls.Add(Me.lblColorHeader2)
        Me.Controls.Add(Me.lblAirHeaderLine2)
        Me.Controls.Add(Me.lblLineBW2)
        Me.Controls.Add(Me.lblLineDump2_2)
        Me.Controls.Add(Me.lblLineDump2_1)
        Me.Controls.Add(Me.lblAirHeaderLine3)
        Me.Controls.Add(Me.lblSolventHeader3)
        Me.Controls.Add(Me.lblGroup00)
        Me.Controls.Add(Me.lblDumpTank)
        Me.Controls.Add(Me.lblGroup04)
        Me.Controls.Add(Me.lblGroup03)
        Me.Controls.Add(Me.lblGroup06)
        Me.Controls.Add(Me.lblGroup05)
        Me.Controls.Add(Me.lblGroup01)
        Me.Controls.Add(Me.lblGroup02)
        Me.Controls.Add(Me.lblShared03)
        Me.Controls.Add(Me.lblLineColStk1)
        Me.Controls.Add(Me.lblGroup09)
        Me.Controls.Add(Me.lblGroup08)
        Me.Controls.Add(Me.picDumpTank)
        Me.Controls.Add(Me.lblOutPressure)
        Me.Controls.Add(Me.lblOutPressureTag)
        Me.Controls.Add(Me.lblLineACS)
        Me.Controls.Add(Me.lblAirHeaderLine1)
        Me.Controls.Add(Me.lblSolventHeader1)
        Me.Controls.Add(Me.lblPntHeader01)
        Me.Controls.Add(Me.lblAirHeader01)
        Me.Controls.Add(Me.lblSolventHeader2)
        Me.Controls.Add(Me.lblGroup14)
        Me.Controls.Add(Me.lblFlowTag)
        Me.Controls.Add(Me.lblGroup28)
        Me.Controls.Add(Me.lblInPressureTag)
        Me.MinimumSize = New System.Drawing.Size(3, 3)
        Me.Name = "uctrlVersabell2_2k"
        Me.Size = New System.Drawing.Size(407, 626)
        CType(Me.picDumpTank, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picApplCleaner, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picVersabellGearsPump01, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picVersabellGearsPump02, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents lblAirHeaderLine1 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader1 As System.Windows.Forms.Label
    Private WithEvents lblPntHeader01 As System.Windows.Forms.Label
    Private WithEvents lblAirHeader01 As System.Windows.Forms.Label
    Private WithEvents lblColorHeader2 As System.Windows.Forms.Label
    Private WithEvents lblAirHeaderLine2 As System.Windows.Forms.Label
    Private WithEvents lblLineBW2 As System.Windows.Forms.Label
    Private WithEvents lblLineDump2_2 As System.Windows.Forms.Label
    Private WithEvents lblLineDump2_1 As System.Windows.Forms.Label
    Private WithEvents lblAirHeaderLine3 As System.Windows.Forms.Label
    Private WithEvents lblLineColStk3 As System.Windows.Forms.Label
    Private WithEvents lblLineSolvAir As System.Windows.Forms.Label
    Private WithEvents lblLineColStk2 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader3 As System.Windows.Forms.Label
    Private WithEvents lblGroup14 As System.Windows.Forms.Label
    Private WithEvents lblLineDump1 As System.Windows.Forms.Label
    Private WithEvents lblGroup00 As System.Windows.Forms.Label
    Private WithEvents lblDumpTank As System.Windows.Forms.Label
    Private WithEvents lblGroup04 As System.Windows.Forms.Label
    Private WithEvents lblGroup03 As System.Windows.Forms.Label
    Private WithEvents lblGroup06 As System.Windows.Forms.Label
    Private WithEvents lblGroup05 As System.Windows.Forms.Label
    Private WithEvents lblGroup01 As System.Windows.Forms.Label
    Private WithEvents lblGroup02 As System.Windows.Forms.Label
    Private WithEvents lblShared03 As System.Windows.Forms.Label
    Private WithEvents lblShared00 As System.Windows.Forms.Label
    Private WithEvents lblLineColStk1 As System.Windows.Forms.Label
    Private WithEvents lblLineBellMan2 As System.Windows.Forms.Label
    Private WithEvents lblGroup09 As System.Windows.Forms.Label
    Private WithEvents lblLineSealAir As System.Windows.Forms.Label
    Private WithEvents lblGroup08 As System.Windows.Forms.Label
    Private WithEvents picDumpTank As System.Windows.Forms.PictureBox
    Private WithEvents lblOutPressure As System.Windows.Forms.Label
    Private WithEvents lblOutPressureTag As System.Windows.Forms.Label
    Private WithEvents picApplCleaner As System.Windows.Forms.PictureBox
    Private WithEvents lblLineACA As System.Windows.Forms.Label
    Private WithEvents lblLineACS As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve0b As uctrlValve
    Private WithEvents UctrlSharedValve2 As uctrlValve
    Private WithEvents UctrlSharedValve1 As uctrlValve
    Private WithEvents lblOutPressure2 As System.Windows.Forms.Label
    Private WithEvents lblShared01 As System.Windows.Forms.Label
    Private WithEvents lblShared02 As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve3 As uctrlValve
    Private WithEvents UctrlGroupValve0 As uctrlValve
    Private WithEvents lblGroup12 As System.Windows.Forms.Label
    Private WithEvents lblGroup11 As System.Windows.Forms.Label
    Private WithEvents lblGroup10 As System.Windows.Forms.Label
    Private WithEvents lblGroup07 As System.Windows.Forms.Label
    Private WithEvents lblGroup15 As System.Windows.Forms.Label
    Private WithEvents lblGroup13 As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve0a As uctrlValve
    Private WithEvents UctrlGroupValve1 As uctrlValve
    Private WithEvents UctrlGroupValve2 As uctrlValve
    Private WithEvents UctrlGroupValve3 As uctrlValve
    Private WithEvents UctrlGroupValve4 As uctrlValve
    Private WithEvents UctrlGroupValve5 As uctrlValve
    Private WithEvents UctrlGroupValve6 As uctrlValve
    Private WithEvents UctrlGroupValve8 As uctrlValve
    Private WithEvents UctrlGroupValve9 As uctrlValve
    Private WithEvents UctrlGroupValve10 As uctrlValve
    Private WithEvents UctrlGroupValve11 As uctrlValve
    Private WithEvents UctrlGroupValve12 As uctrlValve
    Private WithEvents UctrlGroupValve13 As uctrlValve
    Private WithEvents UctrlGroupValve15 As uctrlValve
    Private WithEvents UctrlGroupValve14 As uctrlValve
    Private WithEvents lblAirHeaderLine4 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader4 As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve0 As uctrlValve
    Private WithEvents lblLineWashOut1 As System.Windows.Forms.Label
    Private WithEvents lblLineSolvAir1 As System.Windows.Forms.Label
    Private WithEvents lblLineSolvAir2 As System.Windows.Forms.Label
    Private WithEvents lblLineColStk5 As System.Windows.Forms.Label
    Private WithEvents lblLineBellMan1 As System.Windows.Forms.Label
    Private WithEvents lblLinMix02 As System.Windows.Forms.Label
    Private WithEvents picVersabellGearsPump01 As System.Windows.Forms.PictureBox
    Private WithEvents lblFlow As System.Windows.Forms.Label
    Private WithEvents lblFlowTag As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader2 As System.Windows.Forms.Label
    Private WithEvents UctrlGroupValve7 As uctrlValve
    Private WithEvents UctrlGroupValve26 As uctrlValve
    Private WithEvents UctrlGroupValve16 As uctrlValve
    Private WithEvents UctrlGroupValve21 As uctrlValve
    Private WithEvents UctrlGroupValve17 As uctrlValve
    Private WithEvents UctrlGroupValve18 As uctrlValve
    Private WithEvents UctrlGroupValve19 As uctrlValve
    Private WithEvents UctrlGroupValve20 As uctrlValve
    Private WithEvents UctrlGroupValve22 As uctrlValve
    Private WithEvents UctrlGroupValve23 As uctrlValve
    Private WithEvents UctrlGroupValve24 As uctrlValve
    Private WithEvents UctrlGroupValve27 As uctrlValve
    Private WithEvents UctrlGroupValve28 As uctrlValve
    Private WithEvents UctrlGroupValve29 As uctrlValve
    Private WithEvents UctrlGroupValve30 As uctrlValve
    Private WithEvents UctrlGroupValve25 As uctrlValve
    Private WithEvents UctrlGroupValve31 As uctrlValve
    Private WithEvents lblGroup26 As System.Windows.Forms.Label
    Private WithEvents lblGroup25 As System.Windows.Forms.Label
    Private WithEvents lblGroup23 As System.Windows.Forms.Label
    Private WithEvents lblGroup22 As System.Windows.Forms.Label
    Private WithEvents lblGroup21 As System.Windows.Forms.Label
    Private WithEvents lblGroup20 As System.Windows.Forms.Label
    Private WithEvents lblGroup19 As System.Windows.Forms.Label
    Private WithEvents lblGroup18 As System.Windows.Forms.Label
    Private WithEvents lblGroup17 As System.Windows.Forms.Label
    Private WithEvents lblGroup16 As System.Windows.Forms.Label
    Private WithEvents lblGroup31 As System.Windows.Forms.Label
    Private WithEvents lblGroup30 As System.Windows.Forms.Label
    Private WithEvents lblGroup29 As System.Windows.Forms.Label
    Private WithEvents lblGroup28 As System.Windows.Forms.Label
    Private WithEvents lblGroup27 As System.Windows.Forms.Label
    Private WithEvents lblGroup24 As System.Windows.Forms.Label
    Private WithEvents lblLineSolvAirOut1 As System.Windows.Forms.Label
    Private WithEvents lblLineACA2 As System.Windows.Forms.Label
    Private WithEvents lblLineACA3 As System.Windows.Forms.Label
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents lblLineACVA As System.Windows.Forms.Label
    Private WithEvents picVersabellGearsPump02 As System.Windows.Forms.PictureBox
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader5 As System.Windows.Forms.Label
    Private WithEvents lblLineWashOut2 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader6 As System.Windows.Forms.Label
    Private WithEvents linHdrStack01 As System.Windows.Forms.Label
    Private WithEvents linHdrStack02 As System.Windows.Forms.Label
    Private WithEvents lblLineSolvAirOut2 As System.Windows.Forms.Label
    Private WithEvents lblLineDump3_1 As System.Windows.Forms.Label
    Private WithEvents lblLineColStk4 As System.Windows.Forms.Label
    Private WithEvents linHdrStack03 As System.Windows.Forms.Label
    Private WithEvents lblLinMix01 As System.Windows.Forms.Label
    Private WithEvents lblOutPressure2Tag As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader7 As System.Windows.Forms.Label
    Private WithEvents lblLineFlush2_1 As System.Windows.Forms.Label
    Private WithEvents lblLineFlush2_2 As System.Windows.Forms.Label
    Private WithEvents lblLineFlush As System.Windows.Forms.Label
    Private WithEvents lblLineDump3_2 As System.Windows.Forms.Label
    Private WithEvents lblInPressureTag As System.Windows.Forms.Label
    Private WithEvents lblInPressure2 As System.Windows.Forms.Label
    Private WithEvents lblInPressure As System.Windows.Forms.Label

End Class
