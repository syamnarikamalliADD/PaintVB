﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uctrlVersabell
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uctrlVersabell))
        Me.lblAirHeaderLine1 = New System.Windows.Forms.Label
        Me.lblSolventHeader1 = New System.Windows.Forms.Label
        Me.lblPntHeader01 = New System.Windows.Forms.Label
        Me.lblAirHeader01 = New System.Windows.Forms.Label
        Me.lblSolventHeader2 = New System.Windows.Forms.Label
        Me.lblColorHeader2 = New System.Windows.Forms.Label
        Me.lblAirHeaderLine2 = New System.Windows.Forms.Label
        Me.lblLineBW2 = New System.Windows.Forms.Label
        Me.lblAirHeaderLine3 = New System.Windows.Forms.Label
        Me.lblLineColStk3 = New System.Windows.Forms.Label
        Me.lblLineSolvAir = New System.Windows.Forms.Label
        Me.lblLineInjector = New System.Windows.Forms.Label
        Me.lblLineColStk2 = New System.Windows.Forms.Label
        Me.lblLineBW1 = New System.Windows.Forms.Label
        Me.lblSolventHeader3 = New System.Windows.Forms.Label
        Me.lblGroup02 = New System.Windows.Forms.Label
        Me.lblLineDump1 = New System.Windows.Forms.Label
        Me.lblGroup10 = New System.Windows.Forms.Label
        Me.lblDumpTank = New System.Windows.Forms.Label
        Me.lblGroup04 = New System.Windows.Forms.Label
        Me.lblGroup03 = New System.Windows.Forms.Label
        Me.lblGroup11 = New System.Windows.Forms.Label
        Me.lblGroup05 = New System.Windows.Forms.Label
        Me.lblGroup09 = New System.Windows.Forms.Label
        Me.lblGroup08 = New System.Windows.Forms.Label
        Me.lblShared03 = New System.Windows.Forms.Label
        Me.lblShared00 = New System.Windows.Forms.Label
        Me.lblLineColStk1 = New System.Windows.Forms.Label
        Me.lblLineBellMan2 = New System.Windows.Forms.Label
        Me.lblGroup15 = New System.Windows.Forms.Label
        Me.lblLineSealAir = New System.Windows.Forms.Label
        Me.lblGroup12 = New System.Windows.Forms.Label
        Me.picDumpTank = New System.Windows.Forms.PictureBox
        Me.picApplCleaner = New System.Windows.Forms.PictureBox
        Me.lblLineACDA = New System.Windows.Forms.Label
        Me.lblLineACS = New System.Windows.Forms.Label
        Me.lblOutPressure2 = New System.Windows.Forms.Label
        Me.lblShared01 = New System.Windows.Forms.Label
        Me.lblShared02 = New System.Windows.Forms.Label
        Me.lblGroup06 = New System.Windows.Forms.Label
        Me.lblGroup14 = New System.Windows.Forms.Label
        Me.lblGroup01 = New System.Windows.Forms.Label
        Me.lblGroup07 = New System.Windows.Forms.Label
        Me.lblGroup00 = New System.Windows.Forms.Label
        Me.lblGroup13 = New System.Windows.Forms.Label
        Me.lblAirHeaderLine4 = New System.Windows.Forms.Label
        Me.lblSolventHeader4 = New System.Windows.Forms.Label
        Me.lblLineSolvAir3 = New System.Windows.Forms.Label
        Me.lblLineSolvAir1 = New System.Windows.Forms.Label
        Me.lblLineSolvAir2 = New System.Windows.Forms.Label
        Me.lblLineBellMan1 = New System.Windows.Forms.Label
        Me.lblLineColStk4 = New System.Windows.Forms.Label
        Me.lblFlow = New System.Windows.Forms.Label
        Me.lblFlowTag = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblLineACDA2 = New System.Windows.Forms.Label
        Me.lblLineACDA3 = New System.Windows.Forms.Label
        Me.lblLineACA = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.UctrlGroupValve2 = New uctrlValve
        Me.UctrlSharedValve0 = New uctrlValve
        Me.UctrlSharedValve0b = New uctrlValve
        Me.UctrlGroupValve13 = New uctrlValve
        Me.UctrlGroupValve0 = New uctrlValve
        Me.UctrlGroupValve1 = New uctrlValve
        Me.UctrlGroupValve14 = New uctrlValve
        Me.UctrlGroupValve1212 = New uctrlValve
        Me.UctrlGroupValve15 = New uctrlValve
        Me.UctrlGroupValve12 = New uctrlValve
        Me.UctrlGroupValve7 = New uctrlValve
        Me.UctrlGroupValve11 = New uctrlValve
        Me.UctrlGroupValve5 = New uctrlValve
        Me.UctrlGroupValve4 = New uctrlValve
        Me.UctrlGroupValve3 = New uctrlValve
        Me.UctrlGroupValve8 = New uctrlValve
        Me.UctrlGroupValve9 = New uctrlValve
        Me.UctrlSharedValve0a = New uctrlValve
        Me.UctrlGroupValve10 = New uctrlValve
        Me.UctrlSharedValve3 = New uctrlValve
        Me.UctrlSharedValve1 = New uctrlValve
        Me.UctrlSharedValve2 = New uctrlValve
        CType(Me.picDumpTank, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picApplCleaner, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblAirHeaderLine1
        '
        Me.lblAirHeaderLine1.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine1.Location = New System.Drawing.Point(12, 31)
        Me.lblAirHeaderLine1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine1.Name = "lblAirHeaderLine1"
        Me.lblAirHeaderLine1.Size = New System.Drawing.Size(3, 522)
        Me.lblAirHeaderLine1.TabIndex = 92
        '
        'lblSolventHeader1
        '
        Me.lblSolventHeader1.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.lblSolventHeader1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblSolventHeader1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader1.Location = New System.Drawing.Point(1, 41)
        Me.lblSolventHeader1.Name = "lblSolventHeader1"
        Me.lblSolventHeader1.Size = New System.Drawing.Size(314, 15)
        Me.lblSolventHeader1.TabIndex = 94
        Me.lblSolventHeader1.Text = "Purge Solvent"
        Me.lblSolventHeader1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblPntHeader01
        '
        Me.lblPntHeader01.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblPntHeader01.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lblPntHeader01.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblPntHeader01.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblPntHeader01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPntHeader01.Location = New System.Drawing.Point(1, 1)
        Me.lblPntHeader01.Name = "lblPntHeader01"
        Me.lblPntHeader01.Size = New System.Drawing.Size(314, 19)
        Me.lblPntHeader01.TabIndex = 95
        Me.lblPntHeader01.Text = "Paint"
        Me.lblPntHeader01.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAirHeader01
        '
        Me.lblAirHeader01.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeader01.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lblAirHeader01.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblAirHeader01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeader01.Location = New System.Drawing.Point(1, 23)
        Me.lblAirHeader01.Name = "lblAirHeader01"
        Me.lblAirHeader01.Size = New System.Drawing.Size(314, 14)
        Me.lblAirHeader01.TabIndex = 96
        Me.lblAirHeader01.Text = "Purge Air"
        Me.lblAirHeader01.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblSolventHeader2
        '
        Me.lblSolventHeader2.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader2.Location = New System.Drawing.Point(5, 47)
        Me.lblSolventHeader2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader2.Name = "lblSolventHeader2"
        Me.lblSolventHeader2.Size = New System.Drawing.Size(3, 466)
        Me.lblSolventHeader2.TabIndex = 93
        '
        'lblColorHeader2
        '
        Me.lblColorHeader2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblColorHeader2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblColorHeader2.Location = New System.Drawing.Point(229, 15)
        Me.lblColorHeader2.Name = "lblColorHeader2"
        Me.lblColorHeader2.Size = New System.Drawing.Size(3, 51)
        Me.lblColorHeader2.TabIndex = 121
        '
        'lblAirHeaderLine2
        '
        Me.lblAirHeaderLine2.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine2.ForeColor = System.Drawing.Color.Black
        Me.lblAirHeaderLine2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine2.Location = New System.Drawing.Point(14, 343)
        Me.lblAirHeaderLine2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine2.Name = "lblAirHeaderLine2"
        Me.lblAirHeaderLine2.Size = New System.Drawing.Size(18, 3)
        Me.lblAirHeaderLine2.TabIndex = 126
        Me.lblAirHeaderLine2.Text = "_linAirHeader_40"
        '
        'lblLineBW2
        '
        Me.lblLineBW2.BackColor = System.Drawing.Color.Black
        Me.lblLineBW2.ForeColor = System.Drawing.Color.Black
        Me.lblLineBW2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineBW2.Location = New System.Drawing.Point(101, 426)
        Me.lblLineBW2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineBW2.Name = "lblLineBW2"
        Me.lblLineBW2.Size = New System.Drawing.Size(19, 3)
        Me.lblLineBW2.TabIndex = 122
        '
        'lblAirHeaderLine3
        '
        Me.lblAirHeaderLine3.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine3.Location = New System.Drawing.Point(14, 88)
        Me.lblAirHeaderLine3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine3.Name = "lblAirHeaderLine3"
        Me.lblAirHeaderLine3.Size = New System.Drawing.Size(57, 3)
        Me.lblAirHeaderLine3.TabIndex = 114
        '
        'lblLineColStk3
        '
        Me.lblLineColStk3.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk3.Location = New System.Drawing.Point(202, 146)
        Me.lblLineColStk3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk3.Name = "lblLineColStk3"
        Me.lblLineColStk3.Size = New System.Drawing.Size(3, 176)
        Me.lblLineColStk3.TabIndex = 115
        '
        'lblLineSolvAir
        '
        Me.lblLineSolvAir.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAir.ForeColor = System.Drawing.Color.Black
        Me.lblLineSolvAir.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAir.Location = New System.Drawing.Point(99, 88)
        Me.lblLineSolvAir.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAir.Name = "lblLineSolvAir"
        Me.lblLineSolvAir.Size = New System.Drawing.Size(3, 277)
        Me.lblLineSolvAir.TabIndex = 116
        '
        'lblLineInjector
        '
        Me.lblLineInjector.BackColor = System.Drawing.Color.Black
        Me.lblLineInjector.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineInjector.Location = New System.Drawing.Point(156, 398)
        Me.lblLineInjector.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineInjector.Name = "lblLineInjector"
        Me.lblLineInjector.Size = New System.Drawing.Size(3, 23)
        Me.lblLineInjector.TabIndex = 117
        '
        'lblLineColStk2
        '
        Me.lblLineColStk2.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk2.Location = New System.Drawing.Point(163, 146)
        Me.lblLineColStk2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk2.Name = "lblLineColStk2"
        Me.lblLineColStk2.Size = New System.Drawing.Size(69, 3)
        Me.lblLineColStk2.TabIndex = 118
        '
        'lblLineBW1
        '
        Me.lblLineBW1.BackColor = System.Drawing.Color.Black
        Me.lblLineBW1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineBW1.Location = New System.Drawing.Point(99, 395)
        Me.lblLineBW1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineBW1.Name = "lblLineBW1"
        Me.lblLineBW1.Size = New System.Drawing.Size(3, 34)
        Me.lblLineBW1.TabIndex = 119
        '
        'lblSolventHeader3
        '
        Me.lblSolventHeader3.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader3.Location = New System.Drawing.Point(5, 145)
        Me.lblSolventHeader3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader3.Name = "lblSolventHeader3"
        Me.lblSolventHeader3.Size = New System.Drawing.Size(65, 3)
        Me.lblSolventHeader3.TabIndex = 120
        '
        'lblGroup02
        '
        Me.lblGroup02.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup02.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup02.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup02.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup02.Location = New System.Drawing.Point(48, 421)
        Me.lblGroup02.Name = "lblGroup02"
        Me.lblGroup02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup02.Size = New System.Drawing.Size(48, 35)
        Me.lblGroup02.TabIndex = 111
        Me.lblGroup02.Text = "ACDA 2"
        Me.lblGroup02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLineDump1
        '
        Me.lblLineDump1.BackColor = System.Drawing.Color.Black
        Me.lblLineDump1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineDump1.Location = New System.Drawing.Point(283, 277)
        Me.lblLineDump1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineDump1.Name = "lblLineDump1"
        Me.lblLineDump1.Size = New System.Drawing.Size(3, 161)
        Me.lblLineDump1.TabIndex = 123
        '
        'lblGroup10
        '
        Me.lblGroup10.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup10.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup10.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup10.Location = New System.Drawing.Point(214, 318)
        Me.lblGroup10.Name = "lblGroup10"
        Me.lblGroup10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup10.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup10.TabIndex = 110
        Me.lblGroup10.Text = "Paint Enbl 10"
        Me.lblGroup10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblDumpTank
        '
        Me.lblDumpTank.BackColor = System.Drawing.Color.Transparent
        Me.lblDumpTank.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDumpTank.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblDumpTank.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDumpTank.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDumpTank.Location = New System.Drawing.Point(202, 438)
        Me.lblDumpTank.Name = "lblDumpTank"
        Me.lblDumpTank.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDumpTank.Size = New System.Drawing.Size(57, 29)
        Me.lblDumpTank.TabIndex = 109
        Me.lblDumpTank.Text = "Waste Recovery"
        Me.lblDumpTank.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup04
        '
        Me.lblGroup04.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup04.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup04.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup04.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblGroup04.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup04.Location = New System.Drawing.Point(29, 59)
        Me.lblGroup04.Name = "lblGroup04"
        Me.lblGroup04.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup04.Size = New System.Drawing.Size(40, 29)
        Me.lblGroup04.TabIndex = 108
        Me.lblGroup04.Text = "Purge Air 4"
        Me.lblGroup04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup03
        '
        Me.lblGroup03.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup03.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup03.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup03.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblGroup03.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup03.Location = New System.Drawing.Point(17, 111)
        Me.lblGroup03.Name = "lblGroup03"
        Me.lblGroup03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup03.Size = New System.Drawing.Size(53, 31)
        Me.lblGroup03.TabIndex = 107
        Me.lblGroup03.Text = "Purge Solvent 3"
        Me.lblGroup03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup11
        '
        Me.lblGroup11.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup11.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup11.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup11.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroup11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup11.Location = New System.Drawing.Point(221, 286)
        Me.lblGroup11.Name = "lblGroup11"
        Me.lblGroup11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup11.Size = New System.Drawing.Size(56, 26)
        Me.lblGroup11.TabIndex = 106
        Me.lblGroup11.Text = "Dump 11"
        Me.lblGroup11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup05
        '
        Me.lblGroup05.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup05.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup05.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup05.ForeColor = System.Drawing.Color.Black
        Me.lblGroup05.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup05.Location = New System.Drawing.Point(170, 116)
        Me.lblGroup05.Name = "lblGroup05"
        Me.lblGroup05.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup05.Size = New System.Drawing.Size(53, 21)
        Me.lblGroup05.TabIndex = 105
        Me.lblGroup05.Text = "pCC 05"
        Me.lblGroup05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup09
        '
        Me.lblGroup09.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup09.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup09.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup09.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup09.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup09.Location = New System.Drawing.Point(115, 286)
        Me.lblGroup09.Name = "lblGroup09"
        Me.lblGroup09.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup09.Size = New System.Drawing.Size(49, 30)
        Me.lblGroup09.TabIndex = 104
        Me.lblGroup09.Text = "Injector Wash 9"
        Me.lblGroup09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup08
        '
        Me.lblGroup08.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup08.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup08.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup08.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup08.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup08.Location = New System.Drawing.Point(29, 380)
        Me.lblGroup08.Name = "lblGroup08"
        Me.lblGroup08.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup08.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup08.TabIndex = 103
        Me.lblGroup08.Text = "Bell Wash 8"
        Me.lblGroup08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblShared03
        '
        Me.lblShared03.BackColor = System.Drawing.Color.Transparent
        Me.lblShared03.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared03.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared03.ForeColor = System.Drawing.Color.Black
        Me.lblShared03.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared03.Location = New System.Drawing.Point(238, 62)
        Me.lblShared03.Name = "lblShared03"
        Me.lblShared03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared03.Size = New System.Drawing.Size(55, 28)
        Me.lblShared03.TabIndex = 102
        Me.lblShared03.Text = "Color Enable 3"
        Me.lblShared03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblShared00
        '
        Me.lblShared00.BackColor = System.Drawing.Color.Transparent
        Me.lblShared00.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared00.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared00.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared00.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared00.Location = New System.Drawing.Point(187, 378)
        Me.lblShared00.Name = "lblShared00"
        Me.lblShared00.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared00.Size = New System.Drawing.Size(68, 17)
        Me.lblShared00.TabIndex = 101
        Me.lblShared00.Tag = "0"
        Me.lblShared00.Text = "Trigger 0"
        Me.lblShared00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLineColStk1
        '
        Me.lblLineColStk1.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk1.Location = New System.Drawing.Point(229, 87)
        Me.lblLineColStk1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk1.Name = "lblLineColStk1"
        Me.lblLineColStk1.Size = New System.Drawing.Size(3, 60)
        Me.lblLineColStk1.TabIndex = 124
        '
        'lblLineBellMan2
        '
        Me.lblLineBellMan2.BackColor = System.Drawing.Color.Black
        Me.lblLineBellMan2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineBellMan2.Location = New System.Drawing.Point(156, 345)
        Me.lblLineBellMan2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineBellMan2.Name = "lblLineBellMan2"
        Me.lblLineBellMan2.Size = New System.Drawing.Size(3, 32)
        Me.lblLineBellMan2.TabIndex = 125
        '
        'lblGroup15
        '
        Me.lblGroup15.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup15.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup15.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup15.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroup15.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup15.Location = New System.Drawing.Point(238, 494)
        Me.lblGroup15.Name = "lblGroup15"
        Me.lblGroup15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup15.Size = New System.Drawing.Size(65, 23)
        Me.lblGroup15.TabIndex = 100
        Me.lblGroup15.Text = "lblGroup15"
        Me.lblGroup15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup15.Visible = False
        '
        'lblLineSealAir
        '
        Me.lblLineSealAir.BackColor = System.Drawing.Color.Black
        Me.lblLineSealAir.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSealAir.Location = New System.Drawing.Point(61, 343)
        Me.lblLineSealAir.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSealAir.Name = "lblLineSealAir"
        Me.lblLineSealAir.Size = New System.Drawing.Size(3, 18)
        Me.lblLineSealAir.TabIndex = 127
        '
        'lblGroup12
        '
        Me.lblGroup12.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup12.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup12.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup12.ForeColor = System.Drawing.Color.Black
        Me.lblGroup12.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup12.Location = New System.Drawing.Point(23, 287)
        Me.lblGroup12.Name = "lblGroup12"
        Me.lblGroup12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup12.Size = New System.Drawing.Size(41, 29)
        Me.lblGroup12.TabIndex = 99
        Me.lblGroup12.Text = "Seal Air 12"
        Me.lblGroup12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'picDumpTank
        '
        Me.picDumpTank.Cursor = System.Windows.Forms.Cursors.Default
        Me.picDumpTank.Image = CType(resources.GetObject("picDumpTank.Image"), System.Drawing.Image)
        Me.picDumpTank.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picDumpTank.Location = New System.Drawing.Point(264, 430)
        Me.picDumpTank.Name = "picDumpTank"
        Me.picDumpTank.Size = New System.Drawing.Size(41, 43)
        Me.picDumpTank.TabIndex = 128
        Me.picDumpTank.TabStop = False
        '
        'picApplCleaner
        '
        Me.picApplCleaner.Cursor = System.Windows.Forms.Cursors.Default
        Me.picApplCleaner.Image = CType(resources.GetObject("picApplCleaner.Image"), System.Drawing.Image)
        Me.picApplCleaner.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picApplCleaner.Location = New System.Drawing.Point(127, 501)
        Me.picApplCleaner.Name = "picApplCleaner"
        Me.picApplCleaner.Size = New System.Drawing.Size(60, 60)
        Me.picApplCleaner.TabIndex = 129
        Me.picApplCleaner.TabStop = False
        Me.picApplCleaner.Tag = "imlApplCleaner11"
        '
        'lblLineACDA
        '
        Me.lblLineACDA.BackColor = System.Drawing.Color.Black
        Me.lblLineACDA.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACDA.Location = New System.Drawing.Point(48, 460)
        Me.lblLineACDA.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACDA.Name = "lblLineACDA"
        Me.lblLineACDA.Size = New System.Drawing.Size(50, 3)
        Me.lblLineACDA.TabIndex = 130
        '
        'lblLineACS
        '
        Me.lblLineACS.BackColor = System.Drawing.Color.Black
        Me.lblLineACS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACS.Location = New System.Drawing.Point(48, 513)
        Me.lblLineACS.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACS.Name = "lblLineACS"
        Me.lblLineACS.Size = New System.Drawing.Size(80, 3)
        Me.lblLineACS.TabIndex = 131
        '
        'lblOutPressure2
        '
        Me.lblOutPressure2.BackColor = System.Drawing.SystemColors.Control
        Me.lblOutPressure2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutPressure2.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOutPressure2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblOutPressure2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblOutPressure2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblOutPressure2.Location = New System.Drawing.Point(206, 549)
        Me.lblOutPressure2.Name = "lblOutPressure2"
        Me.lblOutPressure2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOutPressure2.Size = New System.Drawing.Size(39, 18)
        Me.lblOutPressure2.TabIndex = 135
        Me.lblOutPressure2.Text = "000.0"
        Me.lblOutPressure2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblOutPressure2.Visible = False
        '
        'lblShared01
        '
        Me.lblShared01.BackColor = System.Drawing.Color.Transparent
        Me.lblShared01.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared01.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared01.Location = New System.Drawing.Point(255, 514)
        Me.lblShared01.Name = "lblShared01"
        Me.lblShared01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared01.Size = New System.Drawing.Size(57, 18)
        Me.lblShared01.TabIndex = 136
        Me.lblShared01.Text = "lblValve01"
        Me.lblShared01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblShared01.Visible = False
        '
        'lblShared02
        '
        Me.lblShared02.BackColor = System.Drawing.Color.Transparent
        Me.lblShared02.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared02.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared02.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared02.Location = New System.Drawing.Point(255, 500)
        Me.lblShared02.Name = "lblShared02"
        Me.lblShared02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared02.Size = New System.Drawing.Size(57, 20)
        Me.lblShared02.TabIndex = 137
        Me.lblShared02.Text = "lblValve02"
        Me.lblShared02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblShared02.Visible = False
        '
        'lblGroup06
        '
        Me.lblGroup06.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup06.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup06.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup06.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup06.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup06.Location = New System.Drawing.Point(198, 512)
        Me.lblGroup06.Name = "lblGroup06"
        Me.lblGroup06.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup06.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup06.TabIndex = 140
        Me.lblGroup06.Text = "lblGroup6"
        Me.lblGroup06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup06.Visible = False
        '
        'lblGroup14
        '
        Me.lblGroup14.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup14.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup14.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup14.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup14.Location = New System.Drawing.Point(198, 525)
        Me.lblGroup14.Name = "lblGroup14"
        Me.lblGroup14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup14.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup14.TabIndex = 141
        Me.lblGroup14.Text = "lblGroup11"
        Me.lblGroup14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup14.Visible = False
        '
        'lblGroup01
        '
        Me.lblGroup01.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup01.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup01.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup01.Location = New System.Drawing.Point(48, 520)
        Me.lblGroup01.Name = "lblGroup01"
        Me.lblGroup01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup01.Size = New System.Drawing.Size(72, 29)
        Me.lblGroup01.TabIndex = 142
        Me.lblGroup01.Text = "ACA 1"
        Me.lblGroup01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup07
        '
        Me.lblGroup07.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup07.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup07.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup07.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup07.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup07.Location = New System.Drawing.Point(211, 217)
        Me.lblGroup07.Name = "lblGroup07"
        Me.lblGroup07.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup07.Size = New System.Drawing.Size(57, 33)
        Me.lblGroup07.TabIndex = 143
        Me.lblGroup07.Text = "RO 7"
        Me.lblGroup07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup00
        '
        Me.lblGroup00.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup00.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup00.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup00.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup00.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup00.Location = New System.Drawing.Point(48, 463)
        Me.lblGroup00.Name = "lblGroup00"
        Me.lblGroup00.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup00.Size = New System.Drawing.Size(48, 44)
        Me.lblGroup00.TabIndex = 144
        Me.lblGroup00.Text = "ACS 0"
        Me.lblGroup00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup13
        '
        Me.lblGroup13.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup13.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup13.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup13.Location = New System.Drawing.Point(199, 494)
        Me.lblGroup13.Name = "lblGroup13"
        Me.lblGroup13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup13.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup13.TabIndex = 145
        Me.lblGroup13.Text = "lblGroup13"
        Me.lblGroup13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup13.Visible = False
        '
        'lblAirHeaderLine4
        '
        Me.lblAirHeaderLine4.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine4.ForeColor = System.Drawing.Color.Black
        Me.lblAirHeaderLine4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine4.Location = New System.Drawing.Point(14, 460)
        Me.lblAirHeaderLine4.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine4.Name = "lblAirHeaderLine4"
        Me.lblAirHeaderLine4.Size = New System.Drawing.Size(7, 3)
        Me.lblAirHeaderLine4.TabIndex = 163
        Me.lblAirHeaderLine4.Text = "_linAirHeader_40"
        '
        'lblSolventHeader4
        '
        Me.lblSolventHeader4.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader4.Location = New System.Drawing.Point(5, 513)
        Me.lblSolventHeader4.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader4.Name = "lblSolventHeader4"
        Me.lblSolventHeader4.Size = New System.Drawing.Size(16, 3)
        Me.lblSolventHeader4.TabIndex = 164
        '
        'lblLineSolvAir3
        '
        Me.lblLineSolvAir3.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAir3.ForeColor = System.Drawing.Color.Black
        Me.lblLineSolvAir3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAir3.Location = New System.Drawing.Point(101, 344)
        Me.lblLineSolvAir3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAir3.Name = "lblLineSolvAir3"
        Me.lblLineSolvAir3.Size = New System.Drawing.Size(26, 3)
        Me.lblLineSolvAir3.TabIndex = 166
        '
        'lblLineSolvAir1
        '
        Me.lblLineSolvAir1.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAir1.ForeColor = System.Drawing.Color.Black
        Me.lblLineSolvAir1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAir1.Location = New System.Drawing.Point(101, 88)
        Me.lblLineSolvAir1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAir1.Name = "lblLineSolvAir1"
        Me.lblLineSolvAir1.Size = New System.Drawing.Size(65, 3)
        Me.lblLineSolvAir1.TabIndex = 167
        '
        'lblLineSolvAir2
        '
        Me.lblLineSolvAir2.BackColor = System.Drawing.Color.Black
        Me.lblLineSolvAir2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineSolvAir2.Location = New System.Drawing.Point(163, 91)
        Me.lblLineSolvAir2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineSolvAir2.Name = "lblLineSolvAir2"
        Me.lblLineSolvAir2.Size = New System.Drawing.Size(3, 24)
        Me.lblLineSolvAir2.TabIndex = 168
        '
        'lblLineBellMan1
        '
        Me.lblLineBellMan1.BackColor = System.Drawing.Color.Black
        Me.lblLineBellMan1.ForeColor = System.Drawing.Color.Black
        Me.lblLineBellMan1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineBellMan1.Location = New System.Drawing.Point(159, 344)
        Me.lblLineBellMan1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineBellMan1.Name = "lblLineBellMan1"
        Me.lblLineBellMan1.Size = New System.Drawing.Size(46, 3)
        Me.lblLineBellMan1.TabIndex = 170
        '
        'lblLineColStk4
        '
        Me.lblLineColStk4.BackColor = System.Drawing.Color.Black
        Me.lblLineColStk4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineColStk4.Location = New System.Drawing.Point(205, 275)
        Me.lblLineColStk4.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineColStk4.Name = "lblLineColStk4"
        Me.lblLineColStk4.Size = New System.Drawing.Size(50, 3)
        Me.lblLineColStk4.TabIndex = 171
        '
        'lblFlow
        '
        Me.lblFlow.BackColor = System.Drawing.SystemColors.Control
        Me.lblFlow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFlow.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFlow.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblFlow.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFlow.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblFlow.Location = New System.Drawing.Point(130, 208)
        Me.lblFlow.Name = "lblFlow"
        Me.lblFlow.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFlow.Size = New System.Drawing.Size(39, 18)
        Me.lblFlow.TabIndex = 175
        Me.lblFlow.Text = "000.0"
        Me.lblFlow.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblFlowTag
        '
        Me.lblFlowTag.BackColor = System.Drawing.Color.Transparent
        Me.lblFlowTag.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFlowTag.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblFlowTag.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFlowTag.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblFlowTag.Location = New System.Drawing.Point(115, 161)
        Me.lblFlowTag.Name = "lblFlowTag"
        Me.lblFlowTag.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFlowTag.Size = New System.Drawing.Size(72, 47)
        Me.lblFlowTag.TabIndex = 176
        Me.lblFlowTag.Text = "Commanded Flow Rate (cc/min)"
        Me.lblFlowTag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Blue
        Me.Label1.ForeColor = System.Drawing.Color.Black
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(12, 552)
        Me.Label1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(7, 3)
        Me.Label1.TabIndex = 177
        Me.Label1.Text = "_linAirHeader_40"
        '
        'lblLineACDA2
        '
        Me.lblLineACDA2.BackColor = System.Drawing.Color.Black
        Me.lblLineACDA2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACDA2.Location = New System.Drawing.Point(96, 460)
        Me.lblLineACDA2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACDA2.Name = "lblLineACDA2"
        Me.lblLineACDA2.Size = New System.Drawing.Size(3, 45)
        Me.lblLineACDA2.TabIndex = 214
        '
        'lblLineACDA3
        '
        Me.lblLineACDA3.BackColor = System.Drawing.Color.Black
        Me.lblLineACDA3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACDA3.Location = New System.Drawing.Point(97, 502)
        Me.lblLineACDA3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACDA3.Name = "lblLineACDA3"
        Me.lblLineACDA3.Size = New System.Drawing.Size(30, 3)
        Me.lblLineACDA3.TabIndex = 215
        '
        'lblLineACA
        '
        Me.lblLineACA.BackColor = System.Drawing.Color.Black
        Me.lblLineACA.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACA.Location = New System.Drawing.Point(48, 552)
        Me.lblLineACA.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACA.Name = "lblLineACA"
        Me.lblLineACA.Size = New System.Drawing.Size(80, 3)
        Me.lblLineACA.TabIndex = 217
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Blue
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(292, 24)
        Me.Label2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(3, 180)
        Me.Label2.TabIndex = 218
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.Blue
        Me.Label3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label3.Location = New System.Drawing.Point(237, 203)
        Me.Label3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 3)
        Me.Label3.TabIndex = 219
        '
        'UctrlGroupValve2
        '
        Me.UctrlGroupValve2.AutoFit = True
        Me.UctrlGroupValve2.Location = New System.Drawing.Point(21, 437)
        Me.UctrlGroupValve2.Name = "UctrlGroupValve2"
        Me.UctrlGroupValve2.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve2.TabIndex = 162
        Me.UctrlGroupValve2.Tag = "2"
        Me.UctrlGroupValve2.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve2.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve2.ValvState = False
        '
        'UctrlSharedValve0
        '
        Me.UctrlSharedValve0.AutoFit = True
        Me.UctrlSharedValve0.Location = New System.Drawing.Point(150, 377)
        Me.UctrlSharedValve0.Name = "UctrlSharedValve0"
        Me.UctrlSharedValve0.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve0.TabIndex = 165
        Me.UctrlSharedValve0.Tag = "0"
        Me.UctrlSharedValve0.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve0.ValveType = uctrlValve.eValveType.HorzRight
        Me.UctrlSharedValve0.ValvState = False
        '
        'UctrlSharedValve0b
        '
        Me.UctrlSharedValve0b.AutoFit = True
        Me.UctrlSharedValve0b.Location = New System.Drawing.Point(126, 421)
        Me.UctrlSharedValve0b.Name = "UctrlSharedValve0b"
        Me.UctrlSharedValve0b.Size = New System.Drawing.Size(63, 35)
        Me.UctrlSharedValve0b.TabIndex = 132
        Me.UctrlSharedValve0b.Tag = "0"
        Me.UctrlSharedValve0b.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve0b.ValveType = uctrlValve.eValveType.BellCup
        Me.UctrlSharedValve0b.ValvState = False
        '
        'UctrlGroupValve13
        '
        Me.UctrlGroupValve13.AutoFit = True
        Me.UctrlGroupValve13.Location = New System.Drawing.Point(223, 535)
        Me.UctrlGroupValve13.Name = "UctrlGroupValve13"
        Me.UctrlGroupValve13.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve13.TabIndex = 161
        Me.UctrlGroupValve13.Tag = "13"
        Me.UctrlGroupValve13.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve13.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve13.ValvState = False
        Me.UctrlGroupValve13.Visible = False
        '
        'UctrlGroupValve0
        '
        Me.UctrlGroupValve0.AutoFit = True
        Me.UctrlGroupValve0.AutoSize = True
        Me.UctrlGroupValve0.Location = New System.Drawing.Point(21, 490)
        Me.UctrlGroupValve0.Name = "UctrlGroupValve0"
        Me.UctrlGroupValve0.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve0.TabIndex = 159
        Me.UctrlGroupValve0.Tag = "0"
        Me.UctrlGroupValve0.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve0.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve0.ValvState = False
        '
        'UctrlGroupValve1
        '
        Me.UctrlGroupValve1.AutoFit = True
        Me.UctrlGroupValve1.Location = New System.Drawing.Point(19, 529)
        Me.UctrlGroupValve1.Name = "UctrlGroupValve1"
        Me.UctrlGroupValve1.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve1.TabIndex = 158
        Me.UctrlGroupValve1.Tag = "1"
        Me.UctrlGroupValve1.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve1.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve1.ValvState = False
        '
        'UctrlGroupValve14
        '
        Me.UctrlGroupValve14.AutoFit = True
        Me.UctrlGroupValve14.Location = New System.Drawing.Point(258, 523)
        Me.UctrlGroupValve14.Name = "UctrlGroupValve14"
        Me.UctrlGroupValve14.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve14.TabIndex = 157
        Me.UctrlGroupValve14.Tag = "11"
        Me.UctrlGroupValve14.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve14.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve14.ValvState = False
        Me.UctrlGroupValve14.Visible = False
        '
        'UctrlGroupValve1212
        '
        Me.UctrlGroupValve1212.AutoFit = True
        Me.UctrlGroupValve1212.AutoSize = True
        Me.UctrlGroupValve1212.Location = New System.Drawing.Point(280, 523)
        Me.UctrlGroupValve1212.Name = "UctrlGroupValve1212"
        Me.UctrlGroupValve1212.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve1212.TabIndex = 156
        Me.UctrlGroupValve1212.Tag = "12"
        Me.UctrlGroupValve1212.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve1212.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve1212.ValvState = False
        Me.UctrlGroupValve1212.Visible = False
        '
        'UctrlGroupValve15
        '
        Me.UctrlGroupValve15.AutoFit = True
        Me.UctrlGroupValve15.Location = New System.Drawing.Point(245, 529)
        Me.UctrlGroupValve15.Name = "UctrlGroupValve15"
        Me.UctrlGroupValve15.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve15.TabIndex = 155
        Me.UctrlGroupValve15.Tag = "9"
        Me.UctrlGroupValve15.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve15.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve15.ValvState = False
        Me.UctrlGroupValve15.Visible = False
        '
        'UctrlGroupValve12
        '
        Me.UctrlGroupValve12.AutoFit = True
        Me.UctrlGroupValve12.Location = New System.Drawing.Point(32, 319)
        Me.UctrlGroupValve12.Name = "UctrlGroupValve12"
        Me.UctrlGroupValve12.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve12.TabIndex = 154
        Me.UctrlGroupValve12.Tag = "12"
        Me.UctrlGroupValve12.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve12.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve12.ValvState = False
        '
        'UctrlGroupValve7
        '
        Me.UctrlGroupValve7.AutoFit = True
        Me.UctrlGroupValve7.Location = New System.Drawing.Point(205, 180)
        Me.UctrlGroupValve7.Name = "UctrlGroupValve7"
        Me.UctrlGroupValve7.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve7.TabIndex = 153
        Me.UctrlGroupValve7.Tag = "7"
        Me.UctrlGroupValve7.ValveColor = uctrlValve.eValveColor.Blue
        Me.UctrlGroupValve7.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve7.ValvState = False
        '
        'UctrlGroupValve11
        '
        Me.UctrlGroupValve11.AutoFit = True
        Me.UctrlGroupValve11.Location = New System.Drawing.Point(254, 253)
        Me.UctrlGroupValve11.Name = "UctrlGroupValve11"
        Me.UctrlGroupValve11.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve11.TabIndex = 152
        Me.UctrlGroupValve11.Tag = "11"
        Me.UctrlGroupValve11.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve11.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve11.ValvState = False
        '
        'UctrlGroupValve5
        '
        Me.UctrlGroupValve5.AutoFit = True
        Me.UctrlGroupValve5.Location = New System.Drawing.Point(140, 115)
        Me.UctrlGroupValve5.Name = "UctrlGroupValve5"
        Me.UctrlGroupValve5.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve5.TabIndex = 151
        Me.UctrlGroupValve5.Tag = "5"
        Me.UctrlGroupValve5.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve5.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve5.ValvState = False
        '
        'UctrlGroupValve4
        '
        Me.UctrlGroupValve4.AutoFit = True
        Me.UctrlGroupValve4.Location = New System.Drawing.Point(70, 65)
        Me.UctrlGroupValve4.Name = "UctrlGroupValve4"
        Me.UctrlGroupValve4.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve4.TabIndex = 150
        Me.UctrlGroupValve4.Tag = "4"
        Me.UctrlGroupValve4.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve4.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve4.ValvState = False
        '
        'UctrlGroupValve3
        '
        Me.UctrlGroupValve3.AutoFit = True
        Me.UctrlGroupValve3.Location = New System.Drawing.Point(70, 121)
        Me.UctrlGroupValve3.Name = "UctrlGroupValve3"
        Me.UctrlGroupValve3.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve3.TabIndex = 149
        Me.UctrlGroupValve3.Tag = "3"
        Me.UctrlGroupValve3.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve3.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve3.ValvState = False
        '
        'UctrlGroupValve8
        '
        Me.UctrlGroupValve8.AutoFit = True
        Me.UctrlGroupValve8.Location = New System.Drawing.Point(76, 365)
        Me.UctrlGroupValve8.Name = "UctrlGroupValve8"
        Me.UctrlGroupValve8.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve8.TabIndex = 148
        Me.UctrlGroupValve8.Tag = "8"
        Me.UctrlGroupValve8.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve8.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve8.ValvState = False
        '
        'UctrlGroupValve9
        '
        Me.UctrlGroupValve9.AutoFit = True
        Me.UctrlGroupValve9.Location = New System.Drawing.Point(126, 321)
        Me.UctrlGroupValve9.Name = "UctrlGroupValve9"
        Me.UctrlGroupValve9.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve9.TabIndex = 147
        Me.UctrlGroupValve9.Tag = "9"
        Me.UctrlGroupValve9.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve9.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve9.ValvState = False
        '
        'UctrlSharedValve0a
        '
        Me.UctrlSharedValve0a.AutoFit = True
        Me.UctrlSharedValve0a.Location = New System.Drawing.Point(115, 458)
        Me.UctrlSharedValve0a.Name = "UctrlSharedValve0a"
        Me.UctrlSharedValve0a.Size = New System.Drawing.Size(85, 45)
        Me.UctrlSharedValve0a.TabIndex = 146
        Me.UctrlSharedValve0a.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve0a.ValveType = uctrlValve.eValveType.SprayPattern
        Me.UctrlSharedValve0a.ValvState = False
        '
        'UctrlGroupValve10
        '
        Me.UctrlGroupValve10.AutoFit = True
        Me.UctrlGroupValve10.Location = New System.Drawing.Point(179, 315)
        Me.UctrlGroupValve10.Name = "UctrlGroupValve10"
        Me.UctrlGroupValve10.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve10.TabIndex = 139
        Me.UctrlGroupValve10.Tag = "10"
        Me.UctrlGroupValve10.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve10.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve10.ValvState = False
        '
        'UctrlSharedValve3
        '
        Me.UctrlSharedValve3.AutoFit = True
        Me.UctrlSharedValve3.Location = New System.Drawing.Point(206, 62)
        Me.UctrlSharedValve3.Name = "UctrlSharedValve3"
        Me.UctrlSharedValve3.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve3.TabIndex = 138
        Me.UctrlSharedValve3.Tag = "3"
        Me.UctrlSharedValve3.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve3.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlSharedValve3.ValvState = False
        '
        'UctrlSharedValve1
        '
        Me.UctrlSharedValve1.AutoFit = True
        Me.UctrlSharedValve1.Location = New System.Drawing.Point(258, 549)
        Me.UctrlSharedValve1.Name = "UctrlSharedValve1"
        Me.UctrlSharedValve1.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve1.TabIndex = 134
        Me.UctrlSharedValve1.Tag = "1"
        Me.UctrlSharedValve1.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve1.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlSharedValve1.ValvState = False
        Me.UctrlSharedValve1.Visible = False
        '
        'UctrlSharedValve2
        '
        Me.UctrlSharedValve2.AutoFit = True
        Me.UctrlSharedValve2.AutoSize = True
        Me.UctrlSharedValve2.Location = New System.Drawing.Point(280, 549)
        Me.UctrlSharedValve2.Name = "UctrlSharedValve2"
        Me.UctrlSharedValve2.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve2.TabIndex = 133
        Me.UctrlSharedValve2.Tag = "2"
        Me.UctrlSharedValve2.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve2.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlSharedValve2.ValvState = False
        Me.UctrlSharedValve2.Visible = False
        '
        'uctrlVersabell
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblLineACA)
        Me.Controls.Add(Me.lblLineACDA3)
        Me.Controls.Add(Me.lblLineACDA2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.UctrlGroupValve2)
        Me.Controls.Add(Me.lblLineACDA)
        Me.Controls.Add(Me.picApplCleaner)
        Me.Controls.Add(Me.lblLineColStk3)
        Me.Controls.Add(Me.lblFlow)
        Me.Controls.Add(Me.lblLineDump1)
        Me.Controls.Add(Me.lblLineColStk4)
        Me.Controls.Add(Me.lblLineBellMan1)
        Me.Controls.Add(Me.UctrlSharedValve0)
        Me.Controls.Add(Me.lblLineSolvAir2)
        Me.Controls.Add(Me.lblLineColStk2)
        Me.Controls.Add(Me.lblLineSolvAir1)
        Me.Controls.Add(Me.lblLineSolvAir3)
        Me.Controls.Add(Me.lblLineBellMan2)
        Me.Controls.Add(Me.UctrlSharedValve0b)
        Me.Controls.Add(Me.lblSolventHeader4)
        Me.Controls.Add(Me.lblAirHeaderLine4)
        Me.Controls.Add(Me.lblLineSealAir)
        Me.Controls.Add(Me.lblLineSolvAir)
        Me.Controls.Add(Me.UctrlGroupValve13)
        Me.Controls.Add(Me.UctrlGroupValve0)
        Me.Controls.Add(Me.UctrlGroupValve1)
        Me.Controls.Add(Me.UctrlGroupValve14)
        Me.Controls.Add(Me.UctrlGroupValve1212)
        Me.Controls.Add(Me.UctrlGroupValve15)
        Me.Controls.Add(Me.UctrlGroupValve12)
        Me.Controls.Add(Me.UctrlGroupValve7)
        Me.Controls.Add(Me.UctrlGroupValve11)
        Me.Controls.Add(Me.UctrlGroupValve5)
        Me.Controls.Add(Me.UctrlGroupValve4)
        Me.Controls.Add(Me.UctrlGroupValve3)
        Me.Controls.Add(Me.UctrlGroupValve8)
        Me.Controls.Add(Me.UctrlGroupValve9)
        Me.Controls.Add(Me.UctrlSharedValve0a)
        Me.Controls.Add(Me.lblGroup13)
        Me.Controls.Add(Me.lblGroup00)
        Me.Controls.Add(Me.lblGroup07)
        Me.Controls.Add(Me.lblGroup01)
        Me.Controls.Add(Me.lblGroup14)
        Me.Controls.Add(Me.lblGroup06)
        Me.Controls.Add(Me.UctrlGroupValve10)
        Me.Controls.Add(Me.UctrlSharedValve3)
        Me.Controls.Add(Me.lblShared02)
        Me.Controls.Add(Me.lblShared01)
        Me.Controls.Add(Me.lblOutPressure2)
        Me.Controls.Add(Me.UctrlSharedValve1)
        Me.Controls.Add(Me.UctrlSharedValve2)
        Me.Controls.Add(Me.lblColorHeader2)
        Me.Controls.Add(Me.lblAirHeaderLine2)
        Me.Controls.Add(Me.lblLineBW2)
        Me.Controls.Add(Me.lblAirHeaderLine3)
        Me.Controls.Add(Me.lblLineInjector)
        Me.Controls.Add(Me.lblLineBW1)
        Me.Controls.Add(Me.lblSolventHeader3)
        Me.Controls.Add(Me.lblGroup10)
        Me.Controls.Add(Me.lblDumpTank)
        Me.Controls.Add(Me.lblGroup04)
        Me.Controls.Add(Me.lblGroup03)
        Me.Controls.Add(Me.lblGroup11)
        Me.Controls.Add(Me.lblGroup05)
        Me.Controls.Add(Me.lblGroup09)
        Me.Controls.Add(Me.lblGroup08)
        Me.Controls.Add(Me.lblShared03)
        Me.Controls.Add(Me.lblShared00)
        Me.Controls.Add(Me.lblLineColStk1)
        Me.Controls.Add(Me.lblGroup15)
        Me.Controls.Add(Me.lblGroup12)
        Me.Controls.Add(Me.picDumpTank)
        Me.Controls.Add(Me.lblLineACS)
        Me.Controls.Add(Me.lblAirHeaderLine1)
        Me.Controls.Add(Me.lblSolventHeader1)
        Me.Controls.Add(Me.lblPntHeader01)
        Me.Controls.Add(Me.lblAirHeader01)
        Me.Controls.Add(Me.lblSolventHeader2)
        Me.Controls.Add(Me.lblGroup02)
        Me.Controls.Add(Me.lblFlowTag)
        Me.MinimumSize = New System.Drawing.Size(3, 3)
        Me.Name = "uctrlVersabell"
        Me.Size = New System.Drawing.Size(315, 570)
        CType(Me.picDumpTank, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picApplCleaner, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents lblAirHeaderLine1 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader1 As System.Windows.Forms.Label
    Private WithEvents lblPntHeader01 As System.Windows.Forms.Label
    Private WithEvents lblAirHeader01 As System.Windows.Forms.Label
    Private WithEvents lblColorHeader2 As System.Windows.Forms.Label
    Private WithEvents lblAirHeaderLine2 As System.Windows.Forms.Label
    Private WithEvents lblLineBW2 As System.Windows.Forms.Label
    Private WithEvents lblAirHeaderLine3 As System.Windows.Forms.Label
    Private WithEvents lblLineColStk3 As System.Windows.Forms.Label
    Private WithEvents lblLineSolvAir As System.Windows.Forms.Label
    Private WithEvents lblLineInjector As System.Windows.Forms.Label
    Private WithEvents lblLineColStk2 As System.Windows.Forms.Label
    Private WithEvents lblLineBW1 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader3 As System.Windows.Forms.Label
    Private WithEvents lblGroup02 As System.Windows.Forms.Label
    Private WithEvents lblLineDump1 As System.Windows.Forms.Label
    Private WithEvents lblGroup10 As System.Windows.Forms.Label
    Private WithEvents lblDumpTank As System.Windows.Forms.Label
    Private WithEvents lblGroup04 As System.Windows.Forms.Label
    Private WithEvents lblGroup03 As System.Windows.Forms.Label
    Private WithEvents lblGroup11 As System.Windows.Forms.Label
    Private WithEvents lblGroup05 As System.Windows.Forms.Label
    Private WithEvents lblGroup09 As System.Windows.Forms.Label
    Private WithEvents lblGroup08 As System.Windows.Forms.Label
    Private WithEvents lblShared03 As System.Windows.Forms.Label
    Private WithEvents lblShared00 As System.Windows.Forms.Label
    Private WithEvents lblLineColStk1 As System.Windows.Forms.Label
    Private WithEvents lblLineBellMan2 As System.Windows.Forms.Label
    Private WithEvents lblGroup15 As System.Windows.Forms.Label
    Private WithEvents lblLineSealAir As System.Windows.Forms.Label
    Private WithEvents lblGroup12 As System.Windows.Forms.Label
    Private WithEvents picDumpTank As System.Windows.Forms.PictureBox
    Private WithEvents picApplCleaner As System.Windows.Forms.PictureBox
    Private WithEvents lblLineACDA As System.Windows.Forms.Label
    Private WithEvents lblLineACS As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve0b As uctrlValve
    Private WithEvents UctrlSharedValve2 As uctrlValve
    Private WithEvents UctrlSharedValve1 As uctrlValve
    Private WithEvents lblOutPressure2 As System.Windows.Forms.Label
    Private WithEvents lblShared01 As System.Windows.Forms.Label
    Private WithEvents lblShared02 As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve3 As uctrlValve
    Private WithEvents UctrlGroupValve10 As uctrlValve
    Private WithEvents lblGroup06 As System.Windows.Forms.Label
    Private WithEvents lblGroup14 As System.Windows.Forms.Label
    Private WithEvents lblGroup01 As System.Windows.Forms.Label
    Private WithEvents lblGroup07 As System.Windows.Forms.Label
    Private WithEvents lblGroup00 As System.Windows.Forms.Label
    Private WithEvents lblGroup13 As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve0a As uctrlValve
    Private WithEvents UctrlGroupValve9 As uctrlValve
    Private WithEvents UctrlGroupValve8 As uctrlValve
    Private WithEvents UctrlGroupValve3 As uctrlValve
    Private WithEvents UctrlGroupValve4 As uctrlValve
    Private WithEvents UctrlGroupValve5 As uctrlValve
    Private WithEvents UctrlGroupValve11 As uctrlValve
    Private WithEvents UctrlGroupValve12 As uctrlValve
    Private WithEvents UctrlGroupValve15 As uctrlValve
    Private WithEvents UctrlGroupValve1 As uctrlValve
    Private WithEvents UctrlGroupValve14 As uctrlValve
    Private WithEvents UctrlGroupValve1212 As uctrlValve
    Private WithEvents UctrlGroupValve13 As uctrlValve
    Private WithEvents UctrlGroupValve0 As uctrlValve
    Private WithEvents UctrlGroupValve2 As uctrlValve
    Private WithEvents lblAirHeaderLine4 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader4 As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve0 As uctrlValve
    Private WithEvents lblLineSolvAir3 As System.Windows.Forms.Label
    Private WithEvents lblLineSolvAir1 As System.Windows.Forms.Label
    Private WithEvents lblLineSolvAir2 As System.Windows.Forms.Label
    Private WithEvents lblLineBellMan1 As System.Windows.Forms.Label
    Private WithEvents lblLineColStk4 As System.Windows.Forms.Label
    Private WithEvents lblFlow As System.Windows.Forms.Label
    Private WithEvents lblFlowTag As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader2 As System.Windows.Forms.Label
    Private WithEvents UctrlGroupValve7 As uctrlValve
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents lblLineACDA2 As System.Windows.Forms.Label
    Private WithEvents lblLineACDA3 As System.Windows.Forms.Label
    Private WithEvents lblLineACA As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents Label3 As System.Windows.Forms.Label

End Class
