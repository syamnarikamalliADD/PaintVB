﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class uctrlGun
    Inherits System.Windows.Forms.UserControl

    'UserControl overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(uctrlGun))
        Me.lblAirHeaderLine1 = New System.Windows.Forms.Label
        Me.lblSolventHeader1 = New System.Windows.Forms.Label
        Me.lblPntHeader01 = New System.Windows.Forms.Label
        Me.lblAirHeader01 = New System.Windows.Forms.Label
        Me.lblSolventHeader2 = New System.Windows.Forms.Label
        Me.lblColorHeader2 = New System.Windows.Forms.Label
        Me.lblPaintLine = New System.Windows.Forms.Label
        Me.lblAirHeaderLine3 = New System.Windows.Forms.Label
        Me.lblSolventHeader3 = New System.Windows.Forms.Label
        Me.lblGroup14 = New System.Windows.Forms.Label
        Me.lblLineDump1 = New System.Windows.Forms.Label
        Me.lblGroup00 = New System.Windows.Forms.Label
        Me.lblDumpTank = New System.Windows.Forms.Label
        Me.lblGroup04 = New System.Windows.Forms.Label
        Me.lblGroup03 = New System.Windows.Forms.Label
        Me.lblGroup06 = New System.Windows.Forms.Label
        Me.lblGroup05 = New System.Windows.Forms.Label
        Me.lblGroup01 = New System.Windows.Forms.Label
        Me.lblGroup02 = New System.Windows.Forms.Label
        Me.lblShared03 = New System.Windows.Forms.Label
        Me.lblShared00 = New System.Windows.Forms.Label
        Me.lblGroup09 = New System.Windows.Forms.Label
        Me.lblGroup08 = New System.Windows.Forms.Label
        Me.picDumpTank = New System.Windows.Forms.PictureBox
        Me.picApplCleaner = New System.Windows.Forms.PictureBox
        Me.lblLineACA = New System.Windows.Forms.Label
        Me.lblLineACS = New System.Windows.Forms.Label
        Me.lblOutPressure2 = New System.Windows.Forms.Label
        Me.lblShared01 = New System.Windows.Forms.Label
        Me.lblShared02 = New System.Windows.Forms.Label
        Me.lblGroup12 = New System.Windows.Forms.Label
        Me.lblGroup11 = New System.Windows.Forms.Label
        Me.lblGroup10 = New System.Windows.Forms.Label
        Me.lblGroup07 = New System.Windows.Forms.Label
        Me.lblGroup15 = New System.Windows.Forms.Label
        Me.lblGroup13 = New System.Windows.Forms.Label
        Me.lblAirHeaderLine4 = New System.Windows.Forms.Label
        Me.lblSolventHeader4 = New System.Windows.Forms.Label
        Me.lblFlow = New System.Windows.Forms.Label
        Me.lblFlowTag = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.lblColorStack = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.UctrlGroupValve14 = New uctrlValve
        Me.UctrlSharedValve0 = New uctrlValve
        Me.UctrlGroupValve13 = New uctrlValve
        Me.UctrlGroupValve15 = New uctrlValve
        Me.UctrlGroupValve10 = New uctrlValve
        Me.UctrlGroupValve11 = New uctrlValve
        Me.UctrlGroupValve12 = New uctrlValve
        Me.UctrlGroupValve9 = New uctrlValve
        Me.UctrlGroupValve8 = New uctrlValve
        Me.UctrlGroupValve7 = New uctrlValve
        Me.UctrlGroupValve6 = New uctrlValve
        Me.UctrlGroupValve5 = New uctrlValve
        Me.UctrlGroupValve4 = New uctrlValve
        Me.UctrlGroupValve3 = New uctrlValve
        Me.UctrlGroupValve2 = New uctrlValve
        Me.UctrlGroupValve1 = New uctrlValve
        Me.UctrlGroupValve0 = New uctrlValve
        Me.UctrlSharedValve3 = New uctrlValve
        Me.UctrlSharedValve1 = New uctrlValve
        Me.UctrlSharedValve2 = New uctrlValve
        CType(Me.picDumpTank, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picApplCleaner, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'lblAirHeaderLine1
        '
        Me.lblAirHeaderLine1.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine1.Location = New System.Drawing.Point(12, 31)
        Me.lblAirHeaderLine1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine1.Name = "lblAirHeaderLine1"
        Me.lblAirHeaderLine1.Size = New System.Drawing.Size(3, 469)
        Me.lblAirHeaderLine1.TabIndex = 92
        '
        'lblSolventHeader1
        '
        Me.lblSolventHeader1.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader1.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Bold)
        Me.lblSolventHeader1.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblSolventHeader1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader1.Location = New System.Drawing.Point(1, 41)
        Me.lblSolventHeader1.Name = "lblSolventHeader1"
        Me.lblSolventHeader1.Size = New System.Drawing.Size(314, 15)
        Me.lblSolventHeader1.TabIndex = 94
        Me.lblSolventHeader1.Text = "Purge Solvent"
        Me.lblSolventHeader1.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblPntHeader01
        '
        Me.lblPntHeader01.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblPntHeader01.FlatStyle = System.Windows.Forms.FlatStyle.Popup
        Me.lblPntHeader01.Font = New System.Drawing.Font("Arial", 12.0!, System.Drawing.FontStyle.Bold)
        Me.lblPntHeader01.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblPntHeader01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPntHeader01.Location = New System.Drawing.Point(1, 1)
        Me.lblPntHeader01.Name = "lblPntHeader01"
        Me.lblPntHeader01.Size = New System.Drawing.Size(314, 19)
        Me.lblPntHeader01.TabIndex = 95
        Me.lblPntHeader01.Text = "Paint"
        Me.lblPntHeader01.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblAirHeader01
        '
        Me.lblAirHeader01.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeader01.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold)
        Me.lblAirHeader01.ForeColor = System.Drawing.SystemColors.ActiveCaptionText
        Me.lblAirHeader01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeader01.Location = New System.Drawing.Point(1, 23)
        Me.lblAirHeader01.Name = "lblAirHeader01"
        Me.lblAirHeader01.Size = New System.Drawing.Size(314, 14)
        Me.lblAirHeader01.TabIndex = 96
        Me.lblAirHeader01.Text = "Purge Air"
        Me.lblAirHeader01.TextAlign = System.Drawing.ContentAlignment.TopCenter
        '
        'lblSolventHeader2
        '
        Me.lblSolventHeader2.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader2.Location = New System.Drawing.Point(5, 47)
        Me.lblSolventHeader2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader2.Name = "lblSolventHeader2"
        Me.lblSolventHeader2.Size = New System.Drawing.Size(3, 498)
        Me.lblSolventHeader2.TabIndex = 93
        '
        'lblColorHeader2
        '
        Me.lblColorHeader2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.lblColorHeader2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblColorHeader2.Location = New System.Drawing.Point(229, 15)
        Me.lblColorHeader2.Name = "lblColorHeader2"
        Me.lblColorHeader2.Size = New System.Drawing.Size(3, 99)
        Me.lblColorHeader2.TabIndex = 121
        '
        'lblPaintLine
        '
        Me.lblPaintLine.BackColor = System.Drawing.Color.Black
        Me.lblPaintLine.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblPaintLine.Location = New System.Drawing.Point(156, 152)
        Me.lblPaintLine.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblPaintLine.Name = "lblPaintLine"
        Me.lblPaintLine.Size = New System.Drawing.Size(3, 265)
        Me.lblPaintLine.TabIndex = 112
        '
        'lblAirHeaderLine3
        '
        Me.lblAirHeaderLine3.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine3.Location = New System.Drawing.Point(14, 88)
        Me.lblAirHeaderLine3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine3.Name = "lblAirHeaderLine3"
        Me.lblAirHeaderLine3.Size = New System.Drawing.Size(111, 3)
        Me.lblAirHeaderLine3.TabIndex = 114
        '
        'lblSolventHeader3
        '
        Me.lblSolventHeader3.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader3.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader3.Location = New System.Drawing.Point(5, 145)
        Me.lblSolventHeader3.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader3.Name = "lblSolventHeader3"
        Me.lblSolventHeader3.Size = New System.Drawing.Size(118, 3)
        Me.lblSolventHeader3.TabIndex = 120
        '
        'lblGroup14
        '
        Me.lblGroup14.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup14.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup14.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup14.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup14.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup14.Location = New System.Drawing.Point(46, 459)
        Me.lblGroup14.Name = "lblGroup14"
        Me.lblGroup14.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup14.Size = New System.Drawing.Size(81, 38)
        Me.lblGroup14.TabIndex = 111
        Me.lblGroup14.Text = "Appl Cleaner Air 14"
        Me.lblGroup14.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblLineDump1
        '
        Me.lblLineDump1.BackColor = System.Drawing.Color.Black
        Me.lblLineDump1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineDump1.Location = New System.Drawing.Point(283, 279)
        Me.lblLineDump1.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineDump1.Name = "lblLineDump1"
        Me.lblLineDump1.Size = New System.Drawing.Size(3, 160)
        Me.lblLineDump1.TabIndex = 123
        Me.lblLineDump1.Visible = False
        '
        'lblGroup00
        '
        Me.lblGroup00.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup00.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup00.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup00.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup00.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup00.Location = New System.Drawing.Point(57, 180)
        Me.lblGroup00.Name = "lblGroup00"
        Me.lblGroup00.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup00.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup00.TabIndex = 110
        Me.lblGroup00.Text = "Paint Enbl 0"
        Me.lblGroup00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup00.Visible = False
        '
        'lblDumpTank
        '
        Me.lblDumpTank.BackColor = System.Drawing.Color.Transparent
        Me.lblDumpTank.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblDumpTank.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblDumpTank.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblDumpTank.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblDumpTank.Location = New System.Drawing.Point(202, 438)
        Me.lblDumpTank.Name = "lblDumpTank"
        Me.lblDumpTank.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblDumpTank.Size = New System.Drawing.Size(57, 29)
        Me.lblDumpTank.TabIndex = 109
        Me.lblDumpTank.Text = "Waste Recovery"
        Me.lblDumpTank.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblDumpTank.Visible = False
        '
        'lblGroup04
        '
        Me.lblGroup04.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup04.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup04.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup04.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblGroup04.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup04.Location = New System.Drawing.Point(65, 59)
        Me.lblGroup04.Name = "lblGroup04"
        Me.lblGroup04.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup04.Size = New System.Drawing.Size(40, 29)
        Me.lblGroup04.TabIndex = 108
        Me.lblGroup04.Text = "Purge Air 4"
        Me.lblGroup04.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup03
        '
        Me.lblGroup03.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup03.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup03.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup03.ForeColor = System.Drawing.SystemColors.WindowText
        Me.lblGroup03.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup03.Location = New System.Drawing.Point(53, 111)
        Me.lblGroup03.Name = "lblGroup03"
        Me.lblGroup03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup03.Size = New System.Drawing.Size(53, 31)
        Me.lblGroup03.TabIndex = 107
        Me.lblGroup03.Text = "Purge Solvent 3"
        Me.lblGroup03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup06
        '
        Me.lblGroup06.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup06.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup06.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup06.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroup06.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup06.Location = New System.Drawing.Point(224, 291)
        Me.lblGroup06.Name = "lblGroup06"
        Me.lblGroup06.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup06.Size = New System.Drawing.Size(56, 26)
        Me.lblGroup06.TabIndex = 106
        Me.lblGroup06.Text = "Dump 6"
        Me.lblGroup06.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup05
        '
        Me.lblGroup05.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup05.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup05.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup05.ForeColor = System.Drawing.Color.Black
        Me.lblGroup05.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup05.Location = New System.Drawing.Point(51, 254)
        Me.lblGroup05.Name = "lblGroup05"
        Me.lblGroup05.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup05.Size = New System.Drawing.Size(53, 21)
        Me.lblGroup05.TabIndex = 105
        Me.lblGroup05.Text = "pCC 05"
        Me.lblGroup05.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup05.Visible = False
        '
        'lblGroup01
        '
        Me.lblGroup01.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup01.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup01.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup01.Location = New System.Drawing.Point(53, 359)
        Me.lblGroup01.Name = "lblGroup01"
        Me.lblGroup01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup01.Size = New System.Drawing.Size(49, 30)
        Me.lblGroup01.TabIndex = 104
        Me.lblGroup01.Text = "Injector Wash 1"
        Me.lblGroup01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup01.Visible = False
        '
        'lblGroup02
        '
        Me.lblGroup02.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup02.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup02.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup02.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup02.Location = New System.Drawing.Point(51, 325)
        Me.lblGroup02.Name = "lblGroup02"
        Me.lblGroup02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup02.Size = New System.Drawing.Size(47, 29)
        Me.lblGroup02.TabIndex = 103
        Me.lblGroup02.Text = "Bell Wash 2"
        Me.lblGroup02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup02.Visible = False
        '
        'lblShared03
        '
        Me.lblShared03.BackColor = System.Drawing.Color.Transparent
        Me.lblShared03.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared03.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared03.ForeColor = System.Drawing.Color.Black
        Me.lblShared03.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared03.Location = New System.Drawing.Point(235, 92)
        Me.lblShared03.Name = "lblShared03"
        Me.lblShared03.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared03.Size = New System.Drawing.Size(55, 28)
        Me.lblShared03.TabIndex = 102
        Me.lblShared03.Text = "Color Enable 3"
        Me.lblShared03.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblShared00
        '
        Me.lblShared00.BackColor = System.Drawing.Color.Transparent
        Me.lblShared00.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared00.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared00.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared00.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared00.Location = New System.Drawing.Point(187, 421)
        Me.lblShared00.Name = "lblShared00"
        Me.lblShared00.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared00.Size = New System.Drawing.Size(68, 17)
        Me.lblShared00.TabIndex = 101
        Me.lblShared00.Tag = "0"
        Me.lblShared00.Text = "Trigger 0"
        Me.lblShared00.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup09
        '
        Me.lblGroup09.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup09.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup09.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup09.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblGroup09.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup09.Location = New System.Drawing.Point(238, 152)
        Me.lblGroup09.Name = "lblGroup09"
        Me.lblGroup09.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup09.Size = New System.Drawing.Size(65, 23)
        Me.lblGroup09.TabIndex = 100
        Me.lblGroup09.Text = "Dump-2 9"
        Me.lblGroup09.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup09.Visible = False
        '
        'lblGroup08
        '
        Me.lblGroup08.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup08.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup08.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup08.ForeColor = System.Drawing.Color.Black
        Me.lblGroup08.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup08.Location = New System.Drawing.Point(51, 291)
        Me.lblGroup08.Name = "lblGroup08"
        Me.lblGroup08.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup08.Size = New System.Drawing.Size(41, 29)
        Me.lblGroup08.TabIndex = 99
        Me.lblGroup08.Text = "Seal Air 8"
        Me.lblGroup08.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup08.Visible = False
        '
        'picDumpTank
        '
        Me.picDumpTank.Cursor = System.Windows.Forms.Cursors.Default
        Me.picDumpTank.Image = CType(resources.GetObject("picDumpTank.Image"), System.Drawing.Image)
        Me.picDumpTank.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picDumpTank.Location = New System.Drawing.Point(264, 430)
        Me.picDumpTank.Name = "picDumpTank"
        Me.picDumpTank.Size = New System.Drawing.Size(41, 43)
        Me.picDumpTank.TabIndex = 128
        Me.picDumpTank.TabStop = False
        Me.picDumpTank.Visible = False
        '
        'picApplCleaner
        '
        Me.picApplCleaner.Cursor = System.Windows.Forms.Cursors.Default
        Me.picApplCleaner.Image = CType(resources.GetObject("picApplCleaner.Image"), System.Drawing.Image)
        Me.picApplCleaner.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.picApplCleaner.Location = New System.Drawing.Point(127, 495)
        Me.picApplCleaner.Name = "picApplCleaner"
        Me.picApplCleaner.Size = New System.Drawing.Size(60, 60)
        Me.picApplCleaner.TabIndex = 129
        Me.picApplCleaner.TabStop = False
        Me.picApplCleaner.Tag = "imlApplCleaner11"
        '
        'lblLineACA
        '
        Me.lblLineACA.BackColor = System.Drawing.Color.Black
        Me.lblLineACA.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACA.Location = New System.Drawing.Point(48, 497)
        Me.lblLineACA.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACA.Name = "lblLineACA"
        Me.lblLineACA.Size = New System.Drawing.Size(80, 3)
        Me.lblLineACA.TabIndex = 130
        '
        'lblLineACS
        '
        Me.lblLineACS.BackColor = System.Drawing.Color.Black
        Me.lblLineACS.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblLineACS.Location = New System.Drawing.Point(48, 546)
        Me.lblLineACS.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblLineACS.Name = "lblLineACS"
        Me.lblLineACS.Size = New System.Drawing.Size(80, 3)
        Me.lblLineACS.TabIndex = 131
        '
        'lblOutPressure2
        '
        Me.lblOutPressure2.BackColor = System.Drawing.SystemColors.Control
        Me.lblOutPressure2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblOutPressure2.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblOutPressure2.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblOutPressure2.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblOutPressure2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblOutPressure2.Location = New System.Drawing.Point(206, 549)
        Me.lblOutPressure2.Name = "lblOutPressure2"
        Me.lblOutPressure2.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblOutPressure2.Size = New System.Drawing.Size(39, 18)
        Me.lblOutPressure2.TabIndex = 135
        Me.lblOutPressure2.Text = "000.0"
        Me.lblOutPressure2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblOutPressure2.Visible = False
        '
        'lblShared01
        '
        Me.lblShared01.BackColor = System.Drawing.Color.Transparent
        Me.lblShared01.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared01.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared01.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared01.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared01.Location = New System.Drawing.Point(255, 514)
        Me.lblShared01.Name = "lblShared01"
        Me.lblShared01.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared01.Size = New System.Drawing.Size(57, 18)
        Me.lblShared01.TabIndex = 136
        Me.lblShared01.Text = "lblValve01"
        Me.lblShared01.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblShared01.Visible = False
        '
        'lblShared02
        '
        Me.lblShared02.BackColor = System.Drawing.Color.Transparent
        Me.lblShared02.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblShared02.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblShared02.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblShared02.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblShared02.Location = New System.Drawing.Point(255, 485)
        Me.lblShared02.Name = "lblShared02"
        Me.lblShared02.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblShared02.Size = New System.Drawing.Size(57, 20)
        Me.lblShared02.TabIndex = 137
        Me.lblShared02.Text = "lblValve02"
        Me.lblShared02.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblShared02.Visible = False
        '
        'lblGroup12
        '
        Me.lblGroup12.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup12.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup12.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup12.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup12.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup12.Location = New System.Drawing.Point(198, 512)
        Me.lblGroup12.Name = "lblGroup12"
        Me.lblGroup12.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup12.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup12.TabIndex = 140
        Me.lblGroup12.Text = "lblGroup12"
        Me.lblGroup12.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup12.Visible = False
        '
        'lblGroup11
        '
        Me.lblGroup11.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup11.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup11.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup11.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup11.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup11.Location = New System.Drawing.Point(198, 525)
        Me.lblGroup11.Name = "lblGroup11"
        Me.lblGroup11.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup11.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup11.TabIndex = 141
        Me.lblGroup11.Text = "lblGroup11"
        Me.lblGroup11.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup11.Visible = False
        '
        'lblGroup10
        '
        Me.lblGroup10.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup10.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup10.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup10.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup10.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup10.Location = New System.Drawing.Point(198, 535)
        Me.lblGroup10.Name = "lblGroup10"
        Me.lblGroup10.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup10.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup10.TabIndex = 142
        Me.lblGroup10.Text = "lblGroup10"
        Me.lblGroup10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup10.Visible = False
        '
        'lblGroup07
        '
        Me.lblGroup07.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup07.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup07.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup07.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup07.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup07.Location = New System.Drawing.Point(70, 213)
        Me.lblGroup07.Name = "lblGroup07"
        Me.lblGroup07.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup07.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup07.TabIndex = 143
        Me.lblGroup07.Text = "Flush 7"
        Me.lblGroup07.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup15
        '
        Me.lblGroup15.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup15.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup15.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup15.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup15.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup15.Location = New System.Drawing.Point(53, 508)
        Me.lblGroup15.Name = "lblGroup15"
        Me.lblGroup15.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup15.Size = New System.Drawing.Size(69, 37)
        Me.lblGroup15.TabIndex = 144
        Me.lblGroup15.Text = "Appl Cleaner Solvent 15"
        Me.lblGroup15.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblGroup13
        '
        Me.lblGroup13.BackColor = System.Drawing.Color.Transparent
        Me.lblGroup13.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblGroup13.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblGroup13.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblGroup13.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblGroup13.Location = New System.Drawing.Point(203, 497)
        Me.lblGroup13.Name = "lblGroup13"
        Me.lblGroup13.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblGroup13.Size = New System.Drawing.Size(57, 20)
        Me.lblGroup13.TabIndex = 145
        Me.lblGroup13.Text = "lblGroup13"
        Me.lblGroup13.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblGroup13.Visible = False
        '
        'lblAirHeaderLine4
        '
        Me.lblAirHeaderLine4.BackColor = System.Drawing.Color.Blue
        Me.lblAirHeaderLine4.ForeColor = System.Drawing.Color.Black
        Me.lblAirHeaderLine4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblAirHeaderLine4.Location = New System.Drawing.Point(14, 497)
        Me.lblAirHeaderLine4.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblAirHeaderLine4.Name = "lblAirHeaderLine4"
        Me.lblAirHeaderLine4.Size = New System.Drawing.Size(7, 3)
        Me.lblAirHeaderLine4.TabIndex = 163
        Me.lblAirHeaderLine4.Text = "_linAirHeader_40"
        '
        'lblSolventHeader4
        '
        Me.lblSolventHeader4.BackColor = System.Drawing.Color.Red
        Me.lblSolventHeader4.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblSolventHeader4.Location = New System.Drawing.Point(5, 545)
        Me.lblSolventHeader4.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblSolventHeader4.Name = "lblSolventHeader4"
        Me.lblSolventHeader4.Size = New System.Drawing.Size(16, 3)
        Me.lblSolventHeader4.TabIndex = 164
        '
        'lblFlow
        '
        Me.lblFlow.BackColor = System.Drawing.SystemColors.Control
        Me.lblFlow.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.lblFlow.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFlow.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblFlow.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFlow.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblFlow.Location = New System.Drawing.Point(233, 227)
        Me.lblFlow.Name = "lblFlow"
        Me.lblFlow.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFlow.Size = New System.Drawing.Size(39, 18)
        Me.lblFlow.TabIndex = 175
        Me.lblFlow.Text = "000.0"
        Me.lblFlow.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.lblFlow.Visible = False
        '
        'lblFlowTag
        '
        Me.lblFlowTag.BackColor = System.Drawing.Color.Transparent
        Me.lblFlowTag.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFlowTag.Font = New System.Drawing.Font("Arial", 8.25!)
        Me.lblFlowTag.ForeColor = System.Drawing.SystemColors.ControlText
        Me.lblFlowTag.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblFlowTag.Location = New System.Drawing.Point(218, 180)
        Me.lblFlowTag.Name = "lblFlowTag"
        Me.lblFlowTag.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFlowTag.Size = New System.Drawing.Size(72, 47)
        Me.lblFlowTag.TabIndex = 176
        Me.lblFlowTag.Text = "Commanded Flow Rate (cc/min)"
        Me.lblFlowTag.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblFlowTag.Visible = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(0, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.Label1.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label1.Location = New System.Drawing.Point(205, 111)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(24, 3)
        Me.Label1.TabIndex = 177
        '
        'lblColorStack
        '
        Me.lblColorStack.BackColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.lblColorStack.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.lblColorStack.Location = New System.Drawing.Point(141, 69)
        Me.lblColorStack.MinimumSize = New System.Drawing.Size(3, 3)
        Me.lblColorStack.Name = "lblColorStack"
        Me.lblColorStack.Size = New System.Drawing.Size(34, 84)
        Me.lblColorStack.TabIndex = 178
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.Blue
        Me.Label2.ImeMode = System.Windows.Forms.ImeMode.NoControl
        Me.Label2.Location = New System.Drawing.Point(15, 236)
        Me.Label2.MinimumSize = New System.Drawing.Size(3, 3)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(112, 3)
        Me.Label2.TabIndex = 179
        '
        'UctrlGroupValve14
        '
        Me.UctrlGroupValve14.AutoFit = True
        Me.UctrlGroupValve14.Location = New System.Drawing.Point(21, 474)
        Me.UctrlGroupValve14.Name = "UctrlGroupValve14"
        Me.UctrlGroupValve14.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve14.TabIndex = 162
        Me.UctrlGroupValve14.Tag = "14"
        Me.UctrlGroupValve14.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve14.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve14.ValvState = False
        '
        'UctrlSharedValve0
        '
        Me.UctrlSharedValve0.AutoFit = True
        Me.UctrlSharedValve0.Location = New System.Drawing.Point(132, 407)
        Me.UctrlSharedValve0.Name = "UctrlSharedValve0"
        Me.UctrlSharedValve0.Size = New System.Drawing.Size(50, 60)
        Me.UctrlSharedValve0.TabIndex = 132
        Me.UctrlSharedValve0.Tag = "0"
        Me.UctrlSharedValve0.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve0.ValveType = uctrlValve.eValveType.Gun
        Me.UctrlSharedValve0.ValvState = False
        '
        'UctrlGroupValve13
        '
        Me.UctrlGroupValve13.AutoFit = True
        Me.UctrlGroupValve13.Location = New System.Drawing.Point(178, 551)
        Me.UctrlGroupValve13.Name = "UctrlGroupValve13"
        Me.UctrlGroupValve13.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve13.TabIndex = 161
        Me.UctrlGroupValve13.Tag = "13"
        Me.UctrlGroupValve13.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve13.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve13.ValvState = False
        Me.UctrlGroupValve13.Visible = False
        '
        'UctrlGroupValve15
        '
        Me.UctrlGroupValve15.AutoFit = True
        Me.UctrlGroupValve15.AutoSize = True
        Me.UctrlGroupValve15.Location = New System.Drawing.Point(21, 523)
        Me.UctrlGroupValve15.Name = "UctrlGroupValve15"
        Me.UctrlGroupValve15.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve15.TabIndex = 159
        Me.UctrlGroupValve15.Tag = "15"
        Me.UctrlGroupValve15.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve15.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve15.ValvState = False
        '
        'UctrlGroupValve10
        '
        Me.UctrlGroupValve10.AutoFit = True
        Me.UctrlGroupValve10.Location = New System.Drawing.Point(239, 525)
        Me.UctrlGroupValve10.Name = "UctrlGroupValve10"
        Me.UctrlGroupValve10.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve10.TabIndex = 158
        Me.UctrlGroupValve10.Tag = "10"
        Me.UctrlGroupValve10.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve10.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve10.ValvState = False
        Me.UctrlGroupValve10.Visible = False
        '
        'UctrlGroupValve11
        '
        Me.UctrlGroupValve11.AutoFit = True
        Me.UctrlGroupValve11.Location = New System.Drawing.Point(258, 523)
        Me.UctrlGroupValve11.Name = "UctrlGroupValve11"
        Me.UctrlGroupValve11.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve11.TabIndex = 157
        Me.UctrlGroupValve11.Tag = "11"
        Me.UctrlGroupValve11.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve11.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve11.ValvState = False
        Me.UctrlGroupValve11.Visible = False
        '
        'UctrlGroupValve12
        '
        Me.UctrlGroupValve12.AutoFit = True
        Me.UctrlGroupValve12.AutoSize = True
        Me.UctrlGroupValve12.Location = New System.Drawing.Point(280, 523)
        Me.UctrlGroupValve12.Name = "UctrlGroupValve12"
        Me.UctrlGroupValve12.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve12.TabIndex = 156
        Me.UctrlGroupValve12.Tag = "12"
        Me.UctrlGroupValve12.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve12.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlGroupValve12.ValvState = False
        Me.UctrlGroupValve12.Visible = False
        '
        'UctrlGroupValve9
        '
        Me.UctrlGroupValve9.AutoFit = True
        Me.UctrlGroupValve9.Location = New System.Drawing.Point(210, 152)
        Me.UctrlGroupValve9.Name = "UctrlGroupValve9"
        Me.UctrlGroupValve9.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve9.TabIndex = 155
        Me.UctrlGroupValve9.Tag = "9"
        Me.UctrlGroupValve9.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve9.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve9.ValvState = False
        Me.UctrlGroupValve9.Visible = False
        '
        'UctrlGroupValve8
        '
        Me.UctrlGroupValve8.AutoFit = True
        Me.UctrlGroupValve8.Location = New System.Drawing.Point(26, 287)
        Me.UctrlGroupValve8.Name = "UctrlGroupValve8"
        Me.UctrlGroupValve8.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve8.TabIndex = 154
        Me.UctrlGroupValve8.Tag = "8"
        Me.UctrlGroupValve8.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve8.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve8.ValvState = False
        Me.UctrlGroupValve8.Visible = False
        '
        'UctrlGroupValve7
        '
        Me.UctrlGroupValve7.AutoFit = True
        Me.UctrlGroupValve7.Location = New System.Drawing.Point(127, 213)
        Me.UctrlGroupValve7.Name = "UctrlGroupValve7"
        Me.UctrlGroupValve7.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve7.TabIndex = 153
        Me.UctrlGroupValve7.Tag = "7"
        Me.UctrlGroupValve7.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve7.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve7.ValvState = False
        '
        'UctrlGroupValve6
        '
        Me.UctrlGroupValve6.AutoFit = True
        Me.UctrlGroupValve6.Location = New System.Drawing.Point(254, 256)
        Me.UctrlGroupValve6.Name = "UctrlGroupValve6"
        Me.UctrlGroupValve6.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve6.TabIndex = 152
        Me.UctrlGroupValve6.Tag = "6"
        Me.UctrlGroupValve6.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve6.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve6.ValvState = False
        Me.UctrlGroupValve6.Visible = False
        '
        'UctrlGroupValve5
        '
        Me.UctrlGroupValve5.AutoFit = True
        Me.UctrlGroupValve5.Location = New System.Drawing.Point(21, 253)
        Me.UctrlGroupValve5.Name = "UctrlGroupValve5"
        Me.UctrlGroupValve5.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve5.TabIndex = 151
        Me.UctrlGroupValve5.Tag = "5"
        Me.UctrlGroupValve5.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve5.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve5.ValvState = False
        Me.UctrlGroupValve5.Visible = False
        '
        'UctrlGroupValve4
        '
        Me.UctrlGroupValve4.AutoFit = True
        Me.UctrlGroupValve4.Location = New System.Drawing.Point(110, 65)
        Me.UctrlGroupValve4.Name = "UctrlGroupValve4"
        Me.UctrlGroupValve4.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve4.TabIndex = 150
        Me.UctrlGroupValve4.Tag = "4"
        Me.UctrlGroupValve4.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve4.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve4.ValvState = False
        '
        'UctrlGroupValve3
        '
        Me.UctrlGroupValve3.AutoFit = True
        Me.UctrlGroupValve3.Location = New System.Drawing.Point(110, 121)
        Me.UctrlGroupValve3.Name = "UctrlGroupValve3"
        Me.UctrlGroupValve3.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve3.TabIndex = 149
        Me.UctrlGroupValve3.Tag = "3"
        Me.UctrlGroupValve3.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve3.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve3.ValvState = False
        '
        'UctrlGroupValve2
        '
        Me.UctrlGroupValve2.AutoFit = True
        Me.UctrlGroupValve2.Location = New System.Drawing.Point(21, 325)
        Me.UctrlGroupValve2.Name = "UctrlGroupValve2"
        Me.UctrlGroupValve2.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve2.TabIndex = 148
        Me.UctrlGroupValve2.Tag = "2"
        Me.UctrlGroupValve2.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve2.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve2.ValvState = False
        Me.UctrlGroupValve2.Visible = False
        '
        'UctrlGroupValve1
        '
        Me.UctrlGroupValve1.AutoFit = True
        Me.UctrlGroupValve1.Location = New System.Drawing.Point(26, 357)
        Me.UctrlGroupValve1.Name = "UctrlGroupValve1"
        Me.UctrlGroupValve1.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve1.TabIndex = 147
        Me.UctrlGroupValve1.Tag = "1"
        Me.UctrlGroupValve1.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve1.ValveType = uctrlValve.eValveType.VertRight
        Me.UctrlGroupValve1.ValvState = False
        Me.UctrlGroupValve1.Visible = False
        '
        'UctrlGroupValve0
        '
        Me.UctrlGroupValve0.AutoFit = True
        Me.UctrlGroupValve0.Location = New System.Drawing.Point(21, 180)
        Me.UctrlGroupValve0.Name = "UctrlGroupValve0"
        Me.UctrlGroupValve0.Size = New System.Drawing.Size(32, 32)
        Me.UctrlGroupValve0.TabIndex = 139
        Me.UctrlGroupValve0.Tag = "0"
        Me.UctrlGroupValve0.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlGroupValve0.ValveType = uctrlValve.eValveType.HorzLeft
        Me.UctrlGroupValve0.ValvState = False
        Me.UctrlGroupValve0.Visible = False
        '
        'UctrlSharedValve3
        '
        Me.UctrlSharedValve3.AutoFit = True
        Me.UctrlSharedValve3.Location = New System.Drawing.Point(173, 88)
        Me.UctrlSharedValve3.Name = "UctrlSharedValve3"
        Me.UctrlSharedValve3.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve3.TabIndex = 138
        Me.UctrlSharedValve3.Tag = "3"
        Me.UctrlSharedValve3.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve3.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlSharedValve3.ValvState = False
        '
        'UctrlSharedValve1
        '
        Me.UctrlSharedValve1.AutoFit = True
        Me.UctrlSharedValve1.Location = New System.Drawing.Point(258, 549)
        Me.UctrlSharedValve1.Name = "UctrlSharedValve1"
        Me.UctrlSharedValve1.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve1.TabIndex = 134
        Me.UctrlSharedValve1.Tag = "1"
        Me.UctrlSharedValve1.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve1.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlSharedValve1.ValvState = False
        Me.UctrlSharedValve1.Visible = False
        '
        'UctrlSharedValve2
        '
        Me.UctrlSharedValve2.AutoFit = True
        Me.UctrlSharedValve2.AutoSize = True
        Me.UctrlSharedValve2.Location = New System.Drawing.Point(280, 549)
        Me.UctrlSharedValve2.Name = "UctrlSharedValve2"
        Me.UctrlSharedValve2.Size = New System.Drawing.Size(32, 32)
        Me.UctrlSharedValve2.TabIndex = 133
        Me.UctrlSharedValve2.Tag = "2"
        Me.UctrlSharedValve2.ValveColor = uctrlValve.eValveColor.Green
        Me.UctrlSharedValve2.ValveType = uctrlValve.eValveType.VertLeft
        Me.UctrlSharedValve2.ValvState = False
        Me.UctrlSharedValve2.Visible = False
        '
        'uctrlGun
        '
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblPaintLine)
        Me.Controls.Add(Me.lblColorStack)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.UctrlGroupValve14)
        Me.Controls.Add(Me.lblLineACA)
        Me.Controls.Add(Me.picApplCleaner)
        Me.Controls.Add(Me.lblFlow)
        Me.Controls.Add(Me.lblLineDump1)
        Me.Controls.Add(Me.UctrlSharedValve0)
        Me.Controls.Add(Me.lblSolventHeader4)
        Me.Controls.Add(Me.lblAirHeaderLine4)
        Me.Controls.Add(Me.UctrlGroupValve13)
        Me.Controls.Add(Me.UctrlGroupValve15)
        Me.Controls.Add(Me.UctrlGroupValve10)
        Me.Controls.Add(Me.UctrlGroupValve11)
        Me.Controls.Add(Me.UctrlGroupValve12)
        Me.Controls.Add(Me.UctrlGroupValve9)
        Me.Controls.Add(Me.UctrlGroupValve8)
        Me.Controls.Add(Me.UctrlGroupValve7)
        Me.Controls.Add(Me.UctrlGroupValve6)
        Me.Controls.Add(Me.UctrlGroupValve5)
        Me.Controls.Add(Me.UctrlGroupValve4)
        Me.Controls.Add(Me.UctrlGroupValve3)
        Me.Controls.Add(Me.UctrlGroupValve2)
        Me.Controls.Add(Me.UctrlGroupValve1)
        Me.Controls.Add(Me.lblGroup13)
        Me.Controls.Add(Me.lblGroup15)
        Me.Controls.Add(Me.lblGroup07)
        Me.Controls.Add(Me.lblGroup10)
        Me.Controls.Add(Me.lblGroup11)
        Me.Controls.Add(Me.lblGroup12)
        Me.Controls.Add(Me.UctrlGroupValve0)
        Me.Controls.Add(Me.UctrlSharedValve3)
        Me.Controls.Add(Me.lblShared02)
        Me.Controls.Add(Me.lblShared01)
        Me.Controls.Add(Me.lblOutPressure2)
        Me.Controls.Add(Me.UctrlSharedValve1)
        Me.Controls.Add(Me.UctrlSharedValve2)
        Me.Controls.Add(Me.lblColorHeader2)
        Me.Controls.Add(Me.lblAirHeaderLine3)
        Me.Controls.Add(Me.lblSolventHeader3)
        Me.Controls.Add(Me.lblGroup00)
        Me.Controls.Add(Me.lblDumpTank)
        Me.Controls.Add(Me.lblGroup04)
        Me.Controls.Add(Me.lblGroup03)
        Me.Controls.Add(Me.lblGroup06)
        Me.Controls.Add(Me.lblGroup05)
        Me.Controls.Add(Me.lblGroup01)
        Me.Controls.Add(Me.lblGroup02)
        Me.Controls.Add(Me.lblShared03)
        Me.Controls.Add(Me.lblShared00)
        Me.Controls.Add(Me.lblGroup09)
        Me.Controls.Add(Me.lblGroup08)
        Me.Controls.Add(Me.picDumpTank)
        Me.Controls.Add(Me.lblLineACS)
        Me.Controls.Add(Me.lblAirHeaderLine1)
        Me.Controls.Add(Me.lblSolventHeader1)
        Me.Controls.Add(Me.lblPntHeader01)
        Me.Controls.Add(Me.lblAirHeader01)
        Me.Controls.Add(Me.lblSolventHeader2)
        Me.Controls.Add(Me.lblGroup14)
        Me.Controls.Add(Me.lblFlowTag)
        Me.MinimumSize = New System.Drawing.Size(3, 3)
        Me.Name = "uctrlGun"
        Me.Size = New System.Drawing.Size(315, 570)
        CType(Me.picDumpTank, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picApplCleaner, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Private WithEvents lblAirHeaderLine1 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader1 As System.Windows.Forms.Label
    Private WithEvents lblPntHeader01 As System.Windows.Forms.Label
    Private WithEvents lblAirHeader01 As System.Windows.Forms.Label
    Private WithEvents lblColorHeader2 As System.Windows.Forms.Label
    Private WithEvents lblPaintLine As System.Windows.Forms.Label
    Private WithEvents lblAirHeaderLine3 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader3 As System.Windows.Forms.Label
    Private WithEvents lblGroup14 As System.Windows.Forms.Label
    Private WithEvents lblLineDump1 As System.Windows.Forms.Label
    Private WithEvents lblGroup00 As System.Windows.Forms.Label
    Private WithEvents lblDumpTank As System.Windows.Forms.Label
    Private WithEvents lblGroup04 As System.Windows.Forms.Label
    Private WithEvents lblGroup03 As System.Windows.Forms.Label
    Private WithEvents lblGroup06 As System.Windows.Forms.Label
    Private WithEvents lblGroup05 As System.Windows.Forms.Label
    Private WithEvents lblGroup01 As System.Windows.Forms.Label
    Private WithEvents lblGroup02 As System.Windows.Forms.Label
    Private WithEvents lblShared03 As System.Windows.Forms.Label
    Private WithEvents lblShared00 As System.Windows.Forms.Label
    Private WithEvents lblGroup09 As System.Windows.Forms.Label
    Private WithEvents lblGroup08 As System.Windows.Forms.Label
    Private WithEvents picDumpTank As System.Windows.Forms.PictureBox
    Private WithEvents picApplCleaner As System.Windows.Forms.PictureBox
    Private WithEvents lblLineACA As System.Windows.Forms.Label
    Private WithEvents lblLineACS As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve0 As uctrlValve
    Private WithEvents UctrlSharedValve2 As uctrlValve
    Private WithEvents UctrlSharedValve1 As uctrlValve
    Private WithEvents lblOutPressure2 As System.Windows.Forms.Label
    Private WithEvents lblShared01 As System.Windows.Forms.Label
    Private WithEvents lblShared02 As System.Windows.Forms.Label
    Private WithEvents UctrlSharedValve3 As uctrlValve
    Private WithEvents UctrlGroupValve0 As uctrlValve
    Private WithEvents lblGroup12 As System.Windows.Forms.Label
    Private WithEvents lblGroup11 As System.Windows.Forms.Label
    Private WithEvents lblGroup10 As System.Windows.Forms.Label
    Private WithEvents lblGroup07 As System.Windows.Forms.Label
    Private WithEvents lblGroup15 As System.Windows.Forms.Label
    Private WithEvents lblGroup13 As System.Windows.Forms.Label
    Private WithEvents UctrlGroupValve1 As uctrlValve
    Private WithEvents UctrlGroupValve2 As uctrlValve
    Private WithEvents UctrlGroupValve3 As uctrlValve
    Private WithEvents UctrlGroupValve4 As uctrlValve
    Private WithEvents UctrlGroupValve5 As uctrlValve
    Private WithEvents UctrlGroupValve6 As uctrlValve
    Private WithEvents UctrlGroupValve8 As uctrlValve
    Private WithEvents UctrlGroupValve9 As uctrlValve
    Private WithEvents UctrlGroupValve10 As uctrlValve
    Private WithEvents UctrlGroupValve11 As uctrlValve
    Private WithEvents UctrlGroupValve12 As uctrlValve
    Private WithEvents UctrlGroupValve13 As uctrlValve
    Private WithEvents UctrlGroupValve15 As uctrlValve
    Private WithEvents UctrlGroupValve14 As uctrlValve
    Private WithEvents lblAirHeaderLine4 As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader4 As System.Windows.Forms.Label
    Private WithEvents lblFlow As System.Windows.Forms.Label
    Private WithEvents lblFlowTag As System.Windows.Forms.Label
    Private WithEvents lblSolventHeader2 As System.Windows.Forms.Label
    Private WithEvents UctrlGroupValve7 As uctrlValve
    Private WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents lblColorStack As System.Windows.Forms.Label
    Private WithEvents Label2 As System.Windows.Forms.Label

End Class
